import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const LaughAndChatApp());
}

class LaughAndChatApp extends StatelessWidget {
  const LaughAndChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Laugh & Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        return snapshot.data == null ? const AuthPage() : const HomePage();
      },
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final phone = TextEditingController();
  final code = TextEditingController();

  bool create = false;
  bool phoneMode = false;
  bool codeMode = false;
  bool busy = false;
  String error = '';
  String? verificationId;
  int? resendToken;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    phone.dispose();
    code.dispose();
    super.dispose();
  }

  Future<void> emailSubmit() async {
    if (email.text.trim().isEmpty || password.text.length < 6) {
      setState(() {
        error = 'Enter an email and a password of at least 6 characters.';
      });
      return;
    }

    setState(() {
      busy = true;
      error = '';
    });

    try {
      if (create) {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        setState(() => error = e.message ?? e.code);
      }
    } finally {
      if (mounted) {
        setState(() => busy = false);
      }
    }
  }

  Future<void> sendCode() async {
    if (!phone.text.trim().startsWith('+')) {
      setState(() => error = 'Use international format, e.g. +256700000000');
      return;
    }

    setState(() {
      busy = true;
      error = '';
    });

    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone.text.trim(),
      timeout: const Duration(seconds: 60),
      forceResendingToken: resendToken,
      verificationCompleted: (credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
      },
      verificationFailed: (e) {
        if (mounted) {
          setState(() {
            busy = false;
            error = e.message ?? e.code;
          });
        }
      },
      codeSent: (id, token) {
        if (mounted) {
          setState(() {
            verificationId = id;
            resendToken = token;
            codeMode = true;
            busy = false;
          });
        }
      },
      codeAutoRetrievalTimeout: (id) {
        verificationId = id;
        if (mounted) setState(() => busy = false);
      },
    );
  }

  Future<void> verifyCode() async {
    if (verificationId == null || code.text.trim().length < 4) {
      setState(() => error = 'Enter the SMS verification code.');
      return;
    }

    setState(() {
      busy = true;
      error = '';
    });

    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!,
        smsCode: code.text.trim(),
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() => error = e.message ?? e.code);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.emoji_emotions, size: 80),
                const SizedBox(height: 10),
                const Text(
                  'Laugh & Chat',
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                ),
                const Text('Connect • Chat • Laugh • Share'),
                const SizedBox(height: 28),
                if (!phoneMode) ...[
                  TextField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email address',
                      prefixIcon: Icon(Icons.email),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: password,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      prefixIcon: Icon(Icons.lock),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ] else if (!codeMode) ...[
                  TextField(
                    controller: phone,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Phone number with country code',
                      hintText: '+256700000000',
                      prefixIcon: Icon(Icons.phone),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ] else ...[
                  TextField(
                    controller: phone,
                    readOnly: true,
                    decoration: const InputDecoration(
                      labelText: 'Phone number',
                      prefixIcon: Icon(Icons.phone),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: code,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'SMS verification code',
                      prefixIcon: Icon(Icons.sms),
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
                if (error.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      error,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: busy
                        ? null
                        : (!phoneMode
                            ? emailSubmit
                            : (codeMode ? verifyCode : sendCode)),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Text(
                        busy
                            ? 'Please wait...'
                            : (!phoneMode
                                ? (create ? 'Create account' : 'Log in')
                                : (codeMode
                                    ? 'Verify code'
                                    : 'Send SMS code')),
                      ),
                    ),
                  ),
                ),
                if (!phoneMode) ...[
                  TextButton(
                    onPressed: () {
                      setState(() {
                        create = !create;
                        error = '';
                      });
                    },
                    child: Text(
                      create
                          ? 'Already have an account? Log in'
                          : 'New here? Create an account',
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      if (email.text.trim().isEmpty) {
                        setState(() => error = 'Enter your email first.');
                        return;
                      }
                      try {
                        await FirebaseAuth.instance.sendPasswordResetEmail(
                          email: email.text.trim(),
                        );
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Password reset email sent.'),
                            ),
                          );
                        }
                      } on FirebaseAuthException catch (e) {
                        if (mounted) setState(() => error = e.message ?? e.code);
                      }
                    },
                    child: const Text('Forgot password?'),
                  ),
                ],
                const Divider(height: 30),
                OutlinedButton.icon(
                  onPressed: busy
                      ? null
                      : () {
                          setState(() {
                            phoneMode = !phoneMode;
                            codeMode = false;
                            error = '';
                          });
                        },
                  icon: Icon(phoneMode ? Icons.email : Icons.phone),
                  label: Text(
                    phoneMode ? 'Use email instead' : 'Continue with phone',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    _FeedTab(),
    _UploadTab(),
    _ChatTab(),
    _AlertsTab(),
    _ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Laugh & Chat'),
        actions: [
          IconButton(
            tooltip: 'Camera & Filters',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const CameraStudioPage(),
                ),
              );
            },
            icon: const Icon(Icons.camera_alt),
          ),
          IconButton(
            tooltip: 'Log out',
            onPressed: () => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.upload), label: 'Upload'),
          NavigationDestination(icon: Icon(Icons.chat), label: 'Chat'),
          NavigationDestination(
            icon: Icon(Icons.notifications),
            label: 'Alerts',
          ),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _FeedTab extends StatelessWidget {
  const _FeedTab();

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance
        .collection('videos')
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots();

    return StreamBuilder<QuerySnapshot>(
      stream: stream,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Feed error: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.data!.docs.isEmpty) {
          return const Center(
            child: Text('No videos yet. Be the first to upload!'),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            return VideoCard(doc: snapshot.data!.docs[index]);
          },
        );
      },
    );
  }
}

class VideoCard extends StatefulWidget {
  final DocumentSnapshot doc;

  const VideoCard({super.key, required this.doc});

  @override
  State<VideoCard> createState() => _VideoCardState();
}

class _VideoCardState extends State<VideoCard> {
  VideoPlayerController? controller;
  bool saved = false;

  @override
  void initState() {
    super.initState();
    final data = widget.doc.data() as Map<String, dynamic>;
    final url = data['videoUrl'] as String?;
    if (url != null && url.isNotEmpty) {
      controller = VideoPlayerController.networkUrl(Uri.parse(url));
      controller!.initialize().then((_) {
        if (mounted) setState(() {});
      });
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  Future<void> toggleLike(String uid, bool liked) async {
    await widget.doc.reference.update({
      'likes': liked
          ? FieldValue.arrayRemove([uid])
          : FieldValue.arrayUnion([uid]),
    });
  }

  Future<void> repost(BuildContext context, Map<String, dynamic> data) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    await FirebaseFirestore.instance.collection('reposts').add({
      'uid': user.uid,
      'originalVideoId': widget.doc.id,
      'videoUrl': data['videoUrl'],
      'caption': data['caption'] ?? '',
      'createdAt': FieldValue.serverTimestamp(),
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Video reposted to your profile!')),
      );
    }
  }

  Future<void> showComments(BuildContext context) async {
    final commentController = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(sheetContext).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Comments',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 220,
                child: StreamBuilder<QuerySnapshot>(
                  stream: widget.doc.reference
                      .collection('comments')
                      .orderBy('createdAt', descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    final docs = snapshot.data?.docs ?? [];
                    return ListView(
                      children: docs.map((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        return ListTile(
                          title: Text((data['text'] ?? '').toString()),
                          subtitle: Text(
                            (data['username'] ?? 'User').toString(),
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: commentController,
                        decoration: const InputDecoration(
                          hintText: 'Write a comment',
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () async {
                        if (commentController.text.trim().isEmpty) return;
                        final user = FirebaseAuth.instance.currentUser!;
                        await widget.doc.reference.collection('comments').add({
                          'text': commentController.text.trim(),
                          'uid': user.uid,
                          'username': user.displayName ?? user.email ?? 'User',
                          'createdAt': FieldValue.serverTimestamp(),
                        });
                        commentController.clear();
                      },
                      icon: const Icon(Icons.send),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );

    commentController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = widget.doc.data() as Map<String, dynamic>;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final likes = List<String>.from(data['likes'] ?? const []);
    final liked = uid != null && likes.contains(uid);

    return Card(
      clipBehavior: Clip.antiAlias,
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (controller != null && controller!.value.isInitialized)
            GestureDetector(
              onTap: () {
                if (controller!.value.isPlaying) {
                  controller!.pause();
                } else {
                  controller!.play();
                }
                setState(() {});
              },
              child: AspectRatio(
                aspectRatio: controller!.value.aspectRatio,
                child: VideoPlayer(controller!),
              ),
            )
          else
            Container(
              height: 230,
              width: double.infinity,
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              child: const Center(
                child: Icon(Icons.play_circle, size: 70),
              ),
            ),
          ListTile(
            leading: CircleAvatar(
              backgroundImage: (data['photoUrl'] ?? '').toString().isNotEmpty
                  ? NetworkImage(data['photoUrl'].toString())
                  : null,
              child: (data['photoUrl'] ?? '').toString().isEmpty
                  ? const Icon(Icons.person)
                  : null,
            ),
            title: Text((data['username'] ?? '@user').toString()),
            subtitle: Text((data['caption'] ?? '').toString()),
          ),
          if ((data['description'] ?? '').toString().isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(data['description'].toString()),
            ),
          if ((data['hashtags'] ?? '').toString().isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: Text(
                data['hashtags'].toString(),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
          Row(
            children: [
              IconButton(
                onPressed: uid == null ? null : () => toggleLike(uid, liked),
                icon: Icon(
                  liked ? Icons.favorite : Icons.favorite_border,
                ),
              ),
              Text('${likes.length}'),
              IconButton(
                onPressed: () => showComments(context),
                icon: const Icon(Icons.comment_outlined),
              ),
              IconButton(
                onPressed: () {
                  SharePlus.instance.share(
                    ShareParams(
                      text:
                          '${data['caption'] ?? ''}\n${data['videoUrl'] ?? ''}',
                    ),
                  );
                },
                icon: const Icon(Icons.share),
              ),
              IconButton(
                tooltip: 'Repost',
                onPressed: () => repost(context, data),
                icon: const Icon(Icons.repeat),
              ),
              IconButton(
                tooltip: 'Save',
                onPressed: () => setState(() => saved = !saved),
                icon: Icon(
                  saved ? Icons.bookmark : Icons.bookmark_border,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _UploadTab extends StatefulWidget {
  const _UploadTab();

  @override
  State<_UploadTab> createState() => _UploadTabState();
}

class _UploadTabState extends State<_UploadTab> {
  final picker = ImagePicker();
  final caption = TextEditingController();
  final description = TextEditingController();
  final hashtags = TextEditingController();
  XFile? video;
  double progress = 0;
  bool uploading = false;

  @override
  void dispose() {
    caption.dispose();
    description.dispose();
    hashtags.dispose();
    super.dispose();
  }

  Future<void> pick() async {
    final picked = await picker.pickVideo(source: ImageSource.gallery);
    if (picked != null) setState(() => video = picked);
  }

  Future<void> upload() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || video == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Choose a video first.')),
      );
      return;
    }

    setState(() {
      uploading = true;
      progress = 0;
    });

    try {
      final ref = FirebaseStorage.instance.ref().child(
            'videos/${user.uid}/${DateTime.now().millisecondsSinceEpoch}.mp4',
          );
      final task = ref.putFile(File(video!.path));

      task.snapshotEvents.listen((snapshot) {
        if (!mounted || snapshot.totalBytes == 0) return;
        setState(() {
          progress = snapshot.bytesTransferred / snapshot.totalBytes;
        });
      });

      await task;
      final url = await ref.getDownloadURL();
      final profile = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      final profileData = profile.data() ?? <String, dynamic>{};

      await FirebaseFirestore.instance.collection('videos').add({
        'uid': user.uid,
        'username': profileData['username'] ?? user.displayName ?? user.email ?? '@user',
        'photoUrl': profileData['photoUrl'] ?? user.photoURL ?? '',
        'caption': caption.text.trim(),
        'description': description.text.trim(),
        'hashtags': hashtags.text.trim(),
        'videoUrl': url,
        'likes': <String>[],
        'createdAt': FieldValue.serverTimestamp(),
      });

      caption.clear();
      description.clear();
      hashtags.clear();
      setState(() {
        video = null;
        progress = 0;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Video uploaded successfully!')),
        );
      }
    } on FirebaseException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Upload failed: ${e.message ?? e.code}')),
        );
      }
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'Upload a video',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'Add a caption and description so people know what your video is about.',
        ),
        const SizedBox(height: 20),
        OutlinedButton.icon(
          onPressed: uploading ? null : pick,
          icon: const Icon(Icons.video_library),
          label: Text(
            video == null ? 'Choose video' : 'Video selected: ${video!.name}',
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: caption,
          decoration: const InputDecoration(
            labelText: 'Caption',
            hintText: 'My funniest day 😂',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: description,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Description',
            hintText: 'Tell viewers what your video is about...',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: hashtags,
          decoration: const InputDecoration(
            labelText: 'Hashtags',
            hintText: '#comedy #uganda #laugh',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 20),
        if (uploading) LinearProgressIndicator(value: progress),
        const SizedBox(height: 12),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            onPressed: uploading ? null : upload,
            icon: const Icon(Icons.cloud_upload),
            label: Text(
              uploading
                  ? 'Uploading ${(progress * 100).toStringAsFixed(0)}%'
                  : 'Upload video',
            ),
          ),
        ),
      ],
    );
  }
}

class _ChatTab extends StatelessWidget {
  const _ChatTab();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Chat',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        _chatCard(
          context,
          Icons.public,
          'Community Chat',
          'Chat with everyone',
          const CommunityChatPage(),
        ),
        _chatCard(
          context,
          Icons.person,
          'Private Chat',
          'One-to-one messages',
          const PrivateChatPage(),
        ),
        _chatCard(
          context,
          Icons.group,
          'Group Chat',
          'Create or join a group conversation',
          const GroupChatPage(),
        ),
        _chatCard(
          context,
          Icons.auto_awesome,
          'AI Filters',
          'AI-powered effects',
          const AiFiltersPage(),
        ),
      ],
    );
  }

  Widget _chatCard(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
    Widget page,
  ) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => page),
          );
        },
      ),
    );
  }
}

class CommunityChatPage extends StatefulWidget {
  const CommunityChatPage({super.key});

  @override
  State<CommunityChatPage> createState() => _CommunityChatPageState();
}

class _CommunityChatPageState extends State<CommunityChatPage> {
  final text = TextEditingController();

  @override
  void dispose() {
    text.dispose();
    super.dispose();
  }

  Future<void> send() async {
    if (text.text.trim().isEmpty) return;
    final user = FirebaseAuth.instance.currentUser!;
    await FirebaseFirestore.instance.collection('chat_messages').add({
      'text': text.text.trim(),
      'uid': user.uid,
      'username': user.displayName ?? user.email ?? 'User',
      'createdAt': FieldValue.serverTimestamp(),
    });
    text.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Community Chat')),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chat_messages')
                  .orderBy('createdAt')
                  .limitToLast(100)
                  .snapshots(),
              builder: (context, snapshot) {
                final docs = snapshot.data?.docs ?? [];
                return ListView(
                  children: docs.map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final mine = data['uid'] ==
                        FirebaseAuth.instance.currentUser?.uid;
                    return Align(
                      alignment:
                          mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.all(6),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: mine
                              ? Theme.of(context)
                                  .colorScheme
                                  .primaryContainer
                              : Theme.of(context)
                                  .colorScheme
                                  .surfaceContainerHighest,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              (data['username'] ?? 'User').toString(),
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text((data['text'] ?? '').toString()),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: text,
                      decoration: const InputDecoration(
                        hintText: 'Write a message',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PrivateChatPage extends StatefulWidget {
  const PrivateChatPage({super.key});

  @override
  State<PrivateChatPage> createState() => _PrivateChatPageState();
}

class _PrivateChatPageState extends State<PrivateChatPage> {
  final otherUid = TextEditingController();
  final message = TextEditingController();
  String? activeUid;

  @override
  void dispose() {
    otherUid.dispose();
    message.dispose();
    super.dispose();
  }

  String chatId(String a, String b) {
    final ids = [a, b]..sort();
    return '${ids[0]}_${ids[1]}';
  }

  Future<void> send() async {
    if (activeUid == null || message.text.trim().isEmpty) return;
    final user = FirebaseAuth.instance.currentUser!;
    await FirebaseFirestore.instance
        .collection('private_chats')
        .doc(chatId(user.uid, activeUid!))
        .collection('messages')
        .add({
      'text': message.text.trim(),
      'senderId': user.uid,
      'createdAt': FieldValue.serverTimestamp(),
    });
    message.clear();
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;

    return Scaffold(
      appBar: AppBar(title: const Text('Private Chat')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: otherUid,
                    decoration: const InputDecoration(
                      labelText: 'Friend user ID',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    if (otherUid.text.trim().isNotEmpty) {
                      setState(() => activeUid = otherUid.text.trim());
                    }
                  },
                  icon: const Icon(Icons.person_search),
                ),
              ],
            ),
          ),
          if (activeUid == null)
            const Expanded(
              child: Center(
                child: Text(
                  'Enter the other user\'s Firebase user ID to start a private chat.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('private_chats')
                    .doc(chatId(user.uid, activeUid!))
                    .collection('messages')
                    .orderBy('createdAt')
                    .snapshots(),
                builder: (context, snapshot) {
                  final docs = snapshot.data?.docs ?? [];
                  return ListView(
                    children: docs.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      final mine = data['senderId'] == user.uid;
                      return Align(
                        alignment: mine
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.all(6),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            color: mine
                                ? Theme.of(context)
                                    .colorScheme
                                    .primaryContainer
                                : Theme.of(context)
                                    .colorScheme
                                    .surfaceContainerHighest,
                          ),
                          child: Text((data['text'] ?? '').toString()),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: message,
                      decoration: const InputDecoration(
                        hintText: 'Message',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: activeUid == null ? null : send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class GroupChatPage extends StatefulWidget {
  const GroupChatPage({super.key});

  @override
  State<GroupChatPage> createState() => _GroupChatPageState();
}

class _GroupChatPageState extends State<GroupChatPage> {
  final group = TextEditingController(text: 'My Group');
  final message = TextEditingController();
  String groupId = 'main';

  @override
  void dispose() {
    group.dispose();
    message.dispose();
    super.dispose();
  }

  Future<void> send() async {
    if (message.text.trim().isEmpty) return;
    final user = FirebaseAuth.instance.currentUser!;
    await FirebaseFirestore.instance
        .collection('groups')
        .doc(groupId)
        .collection('messages')
        .add({
      'text': message.text.trim(),
      'senderId': user.uid,
      'username': user.displayName ?? user.email ?? 'User',
      'createdAt': FieldValue.serverTimestamp(),
    });
    message.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(group.text.isEmpty ? 'Group Chat' : group.text),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: TextField(
              controller: group,
              onSubmitted: (_) => setState(() {}),
              decoration: const InputDecoration(
                labelText: 'Group name',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('groups')
                  .doc(groupId)
                  .collection('messages')
                  .orderBy('createdAt')
                  .snapshots(),
              builder: (context, snapshot) {
                final docs = snapshot.data?.docs ?? [];
                return ListView(
                  children: docs.map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    return ListTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.person),
                      ),
                      title: Text((data['username'] ?? 'User').toString()),
                      subtitle: Text((data['text'] ?? '').toString()),
                    );
                  }).toList(),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: message,
                      decoration: const InputDecoration(
                        hintText: 'Message the group',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: send,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CameraStudioPage extends StatefulWidget {
  const CameraStudioPage({super.key});

  @override
  State<CameraStudioPage> createState() => _CameraStudioPageState();
}

class _CameraStudioPageState extends State<CameraStudioPage> {
  final picker = ImagePicker();
  XFile? media;
  bool isVideo = false;
  int filter = 0;

  final filters = <ColorFilter>[
    const ColorFilter.mode(Colors.transparent, BlendMode.dst),
    const ColorFilter.matrix([
      0.33, 0.33, 0.33, 0, 0,
      0.33, 0.33, 0.33, 0, 0,
      0.33, 0.33, 0.33, 0, 0,
      0, 0, 0, 1, 0,
    ]),
    const ColorFilter.matrix([
      1.1, 0, 0, 0, 0,
      0, 1.05, 0, 0, 0,
      0, 0, 0.9, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  ];

  Future<void> takePhoto() async {
    final picked = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 90,
    );
    if (picked != null) {
      setState(() {
        media = picked;
        isVideo = false;
      });
    }
  }

  Future<void> recordVideo() async {
    final picked = await picker.pickVideo(
      source: ImageSource.camera,
      maxDuration: const Duration(minutes: 5),
    );
    if (picked != null) {
      setState(() {
        media = picked;
        isVideo = true;
      });
    }
  }

  Future<void> choose() async {
    final picked = await picker.pickMedia();
    if (picked != null) {
      setState(() {
        media = picked;
        isVideo = picked.mimeType?.startsWith('video/') ?? false;
      });
    }
  }

  Future<void> post() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || media == null) return;

    final extension = isVideo ? 'mp4' : 'jpg';
    final collection = isVideo ? 'videos' : 'photos';
    final ref = FirebaseStorage.instance.ref().child(
          '$collection/${user.uid}/${DateTime.now().millisecondsSinceEpoch}.$extension',
        );

    try {
      await ref.putFile(File(media!.path));
      final url = await ref.getDownloadURL();
      await FirebaseFirestore.instance.collection(collection).add({
        'uid': user.uid,
        'url': url,
        'videoUrl': isVideo ? url : null,
        'filter': filter,
        'caption': '',
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(isVideo ? 'Video posted!' : 'Photo posted!')),
        );
      }
    } on FirebaseException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Post failed: ${e.message ?? e.code}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Camera & Filters')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (media == null)
            Container(
              height: 360,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Center(
                child: Icon(Icons.camera_alt, size: 90),
              ),
            )
          else if (isVideo)
            Container(
              height: 360,
              color: Colors.black,
              child: const Center(
                child: Icon(Icons.videocam, size: 90, color: Colors.white),
              ),
            )
          else
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: ColorFiltered(
                colorFilter: filters[filter],
                child: Image.file(
                  File(media!.path),
                  height: 360,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          const SizedBox(height: 18),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton.icon(
                onPressed: takePhoto,
                icon: const Icon(Icons.camera_alt),
                label: const Text('Take Photo'),
              ),
              FilledButton.icon(
                onPressed: recordVideo,
                icon: const Icon(Icons.videocam),
                label: const Text('Record Video'),
              ),
              OutlinedButton.icon(
                onPressed: choose,
                icon: const Icon(Icons.photo_library),
                label: const Text('Gallery'),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const Text(
            'Filters',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              for (int i = 0; i < filters.length; i++)
                ChoiceChip(
                  label: Text(['Normal', 'B&W', 'Warm'][i]),
                  selected: filter == i,
                  onSelected: (_) => setState(() => filter = i),
                ),
            ],
          ),
          const SizedBox(height: 20),
          Card(
            child: ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: const Text('AI Filters'),
              subtitle: const Text(
                'ChatGPT/OpenAI effects require a secure server connection. Never put an API key inside the APK.',
              ),
              trailing: const Icon(Icons.lock),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AiFiltersPage()),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: media == null ? null : post,
              icon: const Icon(Icons.publish),
              label: const Text('Post'),
            ),
          ),
        ],
      ),
    );
  }
}

class AiFiltersPage extends StatelessWidget {
  const AiFiltersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Filters')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          Icon(Icons.auto_awesome, size: 80),
          SizedBox(height: 12),
          Text(
            'AI-powered filters',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          Text(
            'The app is prepared for secure ChatGPT/OpenAI-powered image and video effects. The API key must stay on a secure backend, not inside the mobile app.',
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Card(
            child: ListTile(
              leading: Icon(Icons.face),
              title: Text('AI portrait style'),
              subtitle: Text('Secure AI backend connection coming next.'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.movie_filter),
              title: Text('AI video effects'),
              subtitle: Text('Secure media-processing service coming next.'),
            ),
          ),
        ],
      ),
    );
  }
}

class _AlertsTab extends StatelessWidget {
  const _AlertsTab();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.notifications_none, size: 70),
          SizedBox(height: 12),
          Text(
            'Notifications',
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
          ),
          Text('Likes, comments and other alerts will appear here.'),
        ],
      ),
    );
  }
}

class _ProfileTab extends StatefulWidget {
  const _ProfileTab();

  @override
  State<_ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<_ProfileTab> {
  final name = TextEditingController();
  final username = TextEditingController();
  final bio = TextEditingController();
  final picker = ImagePicker();

  bool loading = true;
  bool saving = false;
  String? photoUrl;

  User? get user => FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    name.dispose();
    username.dispose();
    bio.dispose();
    super.dispose();
  }

  Future<void> load() async {
    final currentUser = user;
    if (currentUser == null) return;

    name.text = currentUser.displayName ?? '';
    photoUrl = currentUser.photoURL;

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();
      final data = snapshot.data();
      if (data != null) {
        name.text = (data['displayName'] ?? name.text).toString();
        username.text = (data['username'] ?? '').toString();
        bio.text = (data['bio'] ?? '').toString();
        photoUrl = (data['photoUrl'] ?? photoUrl)?.toString();
      }
    } catch (_) {}

    if (mounted) setState(() => loading = false);
  }

  Future<void> changePhoto() async {
    final currentUser = user;
    if (currentUser == null) return;

    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
      maxWidth: 1200,
    );
    if (picked == null) return;

    setState(() => saving = true);

    try {
      final ref = FirebaseStorage.instance
          .ref()
          .child('profile_photos/${currentUser.uid}.jpg');
      await ref.putFile(File(picked.path));
      final url = await ref.getDownloadURL();
      await currentUser.updatePhotoURL(url);
      await FirebaseFirestore.instance.collection('users').doc(currentUser.uid).set(
        {
          'photoUrl': url,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );

      if (mounted) {
        setState(() {
          photoUrl = url;
          saving = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Photo upload failed: $e')),
        );
      }
    }
  }

  Future<void> save() async {
    final currentUser = user;
    if (currentUser == null) return;

    if (name.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter your display name.')),
      );
      return;
    }

    setState(() => saving = true);

    try {
      await currentUser.updateDisplayName(name.text.trim());
      await FirebaseFirestore.instance.collection('users').doc(currentUser.uid).set(
        {
          'displayName': name.text.trim(),
          'username': username.text.trim(),
          'bio': bio.text.trim(),
          'photoUrl': photoUrl,
          'email': currentUser.email,
          'phoneNumber': currentUser.phoneNumber,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );

      if (mounted) {
        setState(() => saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile saved successfully.')),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save profile: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    final hasPhoto = photoUrl != null && photoUrl!.isNotEmpty;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Center(
          child: Stack(
            alignment: Alignment.bottomRight,
            children: [
              CircleAvatar(
                radius: 60,
                backgroundImage: hasPhoto ? NetworkImage(photoUrl!) : null,
                child: hasPhoto ? null : const Icon(Icons.person, size: 60),
              ),
              FloatingActionButton.small(
                onPressed: saving ? null : changePhoto,
                child: const Icon(Icons.camera_alt),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'Edit your profile',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: name,
          decoration: const InputDecoration(
            labelText: 'Display name',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: username,
          decoration: const InputDecoration(
            labelText: 'Username',
            prefixText: '@',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: bio,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'Bio',
            hintText: 'Tell people about yourself',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            onPressed: saving ? null : save,
            icon: const Icon(Icons.save),
            label: Text(saving ? 'Saving...' : 'Save profile'),
          ),
        ),
      ],
    );
  }
}
