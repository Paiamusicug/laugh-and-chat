# Laugh & Chat — Supabase Edition 3.0.0

This build continues from the existing Laugh & Chat v2.2.0 Flutter source. It is a migration of the existing app structure to Supabase, not a blank rebuild.

## Backend
- Supabase Auth for email/password accounts.
- Supabase Postgres for profiles, posts, reactions, comments, reposts, follows, friends, notifications, chat and creator data.
- Supabase Realtime for chat/notification streams.
- Supabase Storage bucket: `media` for photos, videos, audio, profile and cover images.
- Firebase runtime dependencies and Google Services configuration have been removed from the app.

## Supabase project
Project URL is already configured in `lib/supabase_config.dart`.
Paste the Supabase **Publishable key** from Dashboard → Project Settings → API Keys into `supabasePublishableKey`.
Never put a secret/service-role key in the mobile app.

## Database
Run `supabase_schema.sql` in Supabase SQL Editor. It extends the tables created earlier and adds the social, media, chat, notification, product and premiere foundation.

## Included feature foundation
- Email sign-up/login
- Public/private/friends post privacy
- Text posts with captions/descriptions
- Like/reaction emojis, comments, repost, share and save
- Delete your own posts/media
- Supabase photo/video/music uploads
- Profile picture and cover picture
- Camera + filters and editor foundation
- Search users
- Follow and private chat
- Community chat and group-chat foundation
- Message timestamps and different sent/received bubble styling
- Notifications foundation
- Creator shop foundation
- Live/premiere foundation
- Laugh AI product hook for secure backend integration
- Worldwide-ready Supabase architecture

## Advanced features
AI image/video transformations, full video export, WebRTC live broadcasting, voice/video calls and real payments require secure server-side services. The app UI/data model is prepared so these can be added without returning to Firebase.


## v3.0.3 source fixes
- Repost now creates/removes a repost record and Home loads repost events.
- Repost records generate a UUID client-side for compatibility with the current `reposts.id` column.
- Text-post Share now includes `https://laughandchat.com/p/{postId}` plus the caption.
- Video/media Share includes the media URL plus caption.
- Like taps toggle the existing `likes` row instead of causing duplicate-key errors.
- Follow taps toggle the existing `follows` row instead of causing duplicate-key errors.
- Private Chat resolves usernames/display names to the real profile UUID before sending.
- Text-post composer is scrollable with the keyboard open.
- Media records now receive an explicit UUID client-side.
- Storage uploads retry up to three times after connection failures.
