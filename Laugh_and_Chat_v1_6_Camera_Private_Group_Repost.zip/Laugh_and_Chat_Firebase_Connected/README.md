# Laugh & Chat — v1.4

Laugh & Chat is a Flutter social entertainment app with Firebase Authentication.

## v1.4 profile features
- Edit display name
- Edit username
- Edit bio
- Pick a profile photo from the phone gallery
- Upload profile photo to Firebase Storage
- Save profile information in Cloud Firestore

## Firebase setup for profile uploads
In Firebase Console for project `laugh-and-chat`:
1. Enable Cloud Firestore.
2. Enable Storage.
3. Make sure Authentication (Email/Password and Phone) remains enabled.

The app uses the signed-in user's UID for profile data and profile photo paths.
