// Supabase connection for Laugh & Chat.
// Replace SUPABASE_PUBLISHABLE_KEY with the Publishable key from
// Supabase Dashboard -> Project Settings -> API Keys.
const supabaseUrl = 'https://knedortbcjaaprmwuqqg.supabase.co';
const supabasePublishableKey = 'PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE';
