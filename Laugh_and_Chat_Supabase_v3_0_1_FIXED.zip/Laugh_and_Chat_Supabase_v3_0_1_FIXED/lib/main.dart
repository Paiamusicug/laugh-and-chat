import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';
import 'supabase_config.dart';

const appName = 'Laugh & Chat';
const reactions = ['❤️', '😂', '😍', '😮', '😢', '😡', '👍', '👏'];
final sb = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  runApp(const LaughAndChatApp());
}

class LaughAndChatApp extends StatelessWidget {
  const LaughAndChatApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple), useMaterial3: true),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: sb.auth.onAuthStateChange,
      builder: (_, __) => sb.auth.currentSession == null ? const AuthPage() : const HomePage(),
    );
  }
}

class AppLogo extends StatelessWidget {
  final double size;
  const AppLogo({super.key, this.size = 68});
  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size * .22),
      child: Image.asset('assets/logo.png', width: size, height: size, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(width: size, height: size, color: Colors.deepPurple, child: Icon(Icons.emoji_emotions, color: Colors.white, size: size * .58))),
    );
  }
}

Future<void> showError(BuildContext context, Object e) async {
  if (!context.mounted) return;
  await showDialog<void>(context: context, builder: (_) => AlertDialog(title: const Text('Something went wrong'), content: Text(e.toString()), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));
}

String timeText(dynamic value) {
  final d = value is String ? DateTime.tryParse(value) : value is DateTime ? value : null;
  if (d == null) return '';
  final x = d.toLocal();
  return '${x.hour.toString().padLeft(2, '0')}:${x.minute.toString().padLeft(2, '0')}';
}

Future<String> uploadMedia(File file, String folder, {String? contentType}) async {
  final uid = sb.auth.currentUser!.id;
  final ext = file.path.split('.').last.toLowerCase();
  final path = '$uid/$folder/${DateTime.now().millisecondsSinceEpoch}.$ext';
  await sb.storage.from('media').upload(path, file, fileOptions: FileOptions(upsert: false, contentType: contentType));
  return sb.storage.from('media').getPublicUrl(path);
}

Future<void> notifyUser(String userId, String type, String title, String body, String entityId) async {
  try {
    await sb.from('notifications').insert({'user_id': userId, 'actor_id': sb.auth.currentUser?.id, 'type': type, 'title': title, 'body': body, 'entity_id': entityId});
  } catch (_) {}
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override State<AuthPage> createState() => _AuthPageState();
}
class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool create = false, busy = false, showPass = false;
  String error = '';
  @override void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  Future<void> submit() async {
    if (email.text.trim().isEmpty || password.text.length < 8) { setState(() => error = 'Enter an email and password of at least 8 characters.'); return; }
    setState(() => busy = true);
    try {
      if (create) {
        final r = await sb.auth.signUp(email: email.text.trim(), password: password.text);
        if (r.user != null) {
          await sb.from('profiles').upsert({'id': r.user!.id, 'email': r.user!.email, 'username': 'user_${r.user!.id.substring(0, 6)}', 'username_lower': 'user_${r.user!.id.substring(0, 6)}'});
        }
      } else {
        await sb.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } on AuthException catch (e) { setState(() => error = e.message); }
    catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) {
    return Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(22), child: Column(children: [
      const AppLogo(size: 110), const SizedBox(height: 12), const Text(appName, style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
      const Text('Connect • Chat • Create • Enjoy'), const SizedBox(height: 24),
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email), border: OutlineInputBorder())),
      const SizedBox(height: 12), TextField(controller: password, obscureText: !showPass, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock), border: const OutlineInputBorder(), suffixIcon: IconButton(onPressed: () => setState(() => showPass = !showPass), icon: Icon(showPass ? Icons.visibility_off : Icons.visibility)))),
      if (error.isNotEmpty) Padding(padding: const EdgeInsets.all(10), child: Text(error, textAlign: TextAlign.center)), const SizedBox(height: 10),
      SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'Please wait...' : create ? 'Create account' : 'Log in'))),
      TextButton(onPressed: busy ? null : () => setState(() => create = !create), child: Text(create ? 'Already have an account? Log in' : 'New here? Create an account')),
      const Text('Phone/SMS can be enabled later in Supabase Authentication.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12)),
    )))));
  }
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [FeedTab(), SearchTab(), CreateTab(), ChatTab(), ProfileTab()];
  @override Widget build(BuildContext context) => Scaffold(body: pages[index], bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), destinations: const [
    NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'), NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
    NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: 'Create'), NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat), label: 'Chat'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
  ]));
}

class FeedTab extends StatefulWidget { const FeedTab({super.key}); @override State<FeedTab> createState() => _FeedTabState(); }
class _FeedTabState extends State<FeedTab> {
  bool loading = true; List<Map<String, dynamic>> posts = []; List<Map<String, dynamic>> media = [];
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final uid = sb.auth.currentUser!.id;
      final p = await sb.from('posts').select().or('privacy.eq.public,owner_id.eq.$uid').order('created_at', ascending: false).limit(50);
      final m = await sb.from('media').select().eq('media_type', 'video').or('privacy.eq.public,owner_id.eq.$uid').order('created_at', ascending: false).limit(50);
      if (mounted) setState(() { posts = List<Map<String, dynamic>>.from(p); media = List<Map<String, dynamic>>.from(m); loading = false; });
    } catch (e) { if (mounted) { setState(() => loading = false); await showError(context, e); } }
  }
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Row(children: const [AppLogo(size: 36), SizedBox(width: 8), Text(appName, style: TextStyle(fontWeight: FontWeight.bold))]), actions: [
      IconButton(onPressed: load, icon: const Icon(Icons.refresh)), IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage())), icon: const Icon(Icons.notifications_none)),
    ]), body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.only(bottom: 80), children: [
      const WelcomeCard(), if (posts.isEmpty && media.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No posts or videos yet. Be the first to share!'))),
      ...posts.map((p) => TextPostCard(post: p, onChanged: load)), ...media.map((m) => VideoCard(media: m, onChanged: load)),
    ]))));
  }
}

class WelcomeCard extends StatelessWidget { const WelcomeCard({super.key}); @override Widget build(BuildContext context) => Card(margin: const EdgeInsets.all(12), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
  const Text('Welcome to Laugh & Chat', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), const SizedBox(height: 5), const Text('Laugh • Create • Chat • Discover • Earn'), const SizedBox(height: 10),
  FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TextPostPage())), icon: const Icon(Icons.edit), label: const Text("What's on your mind?")),
]))); }

class TextPostCard extends StatelessWidget {
  final Map<String, dynamic> post; final VoidCallback onChanged;
  const TextPostCard({super.key, required this.post, required this.onChanged});
  Future<void> deletePost(BuildContext context) async { try { await sb.from('posts').delete().eq('id', post['id']).eq('owner_id', sb.auth.currentUser!.id); onChanged(); } catch (e) { if (context.mounted) await showError(context, e); } }
  Future<void> react(BuildContext context, String reaction) async { try { await sb.from('likes').upsert({'post_id': post['id'], 'user_id': sb.auth.currentUser!.id, 'reaction': reaction}); onChanged(); } catch (e) { if (context.mounted) await showError(context, e); } }
  @override Widget build(BuildContext context) {
    final mine = '${post['owner_id']}' == sb.auth.currentUser?.id;
    return Card(margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [CircleAvatar(child: const Icon(Icons.person)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${post['username'] ?? 'User'}', style: const TextStyle(fontWeight: FontWeight.bold)), Text(timeText(post['created_at']), style: const TextStyle(fontSize: 12))])), if (mine) IconButton(onPressed: () => deletePost(context), icon: const Icon(Icons.delete_outline))]),
      const SizedBox(height: 8), Text('${post['caption'] ?? ''}', style: const TextStyle(fontSize: 17)), const SizedBox(height: 10),
      Wrap(spacing: 2, children: reactions.map((r) => IconButton(onPressed: () => react(context, r), icon: Text(r))).toList()),
      Row(children: [TextButton.icon(onPressed: () => showComments(context, post['id'].toString()), icon: const Icon(Icons.comment), label: const Text('Comment')), TextButton.icon(onPressed: () => SharePlus.instance.share(ShareParams(text: '${post['caption']}')), icon: const Icon(Icons.share), label: const Text('Share')), TextButton.icon(onPressed: () async { try { await sb.from('reposts').insert({'post_id': post['id'], 'user_id': sb.auth.currentUser!.id}); } catch (_) {} }, icon: const Icon(Icons.repeat), label: const Text('Repost'))]),
    ]))));
  }
}

Future<void> showComments(BuildContext context, String postId) async {
  final c = TextEditingController();
  await showDialog<void>(context: context, builder: (_) => AlertDialog(title: const Text('Comments'), content: TextField(controller: c, maxLines: 3, decoration: const InputDecoration(hintText: 'Write a comment...', border: OutlineInputBorder())), actions: [
    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () async { if (c.text.trim().isEmpty) return; try { await sb.from('comments').insert({'post_id': postId, 'user_id': sb.auth.currentUser!.id, 'text': c.text.trim(), 'created_at': DateTime.now().toIso8601String()}); if (context.mounted) Navigator.pop(context); } catch (e) { if (context.mounted) await showError(context, e); } }, child: const Text('Post')),
  ]));
  c.dispose();
}

class VideoCard extends StatefulWidget { final Map<String, dynamic> media; final VoidCallback onChanged; const VideoCard({super.key, required this.media, required this.onChanged}); @override State<VideoCard> createState() => _VideoCardState(); }
class _VideoCardState extends State<VideoCard> {
  VideoPlayerController? controller; bool saved = false;
  @override void initState() { super.initState(); controller = VideoPlayerController.networkUrl(Uri.parse('${widget.media['public_url']}'))..initialize().then((_) { if (mounted) setState(() {}); }); }
  @override void dispose() { controller?.dispose(); super.dispose(); }
  Future<void> del() async { try { await sb.from('media').delete().eq('id', widget.media['id']).eq('owner_id', sb.auth.currentUser!.id); widget.onChanged(); } catch (e) { if (mounted) await showError(context, e); } }
  @override Widget build(BuildContext context) { final mine = '${widget.media['owner_id']}' == sb.auth.currentUser?.id; final c = controller; return Card(margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    if (c?.value.isInitialized == true) AspectRatio(aspectRatio: c!.value.aspectRatio, child: Stack(alignment: Alignment.center, children: [VideoPlayer(c), IconButton(onPressed: () => setState(() => c.value.isPlaying ? c.pause() : c.play()), icon: Icon(c.value.isPlaying ? Icons.pause_circle : Icons.play_circle, color: Colors.white, size: 64))])) else const SizedBox(height: 230, child: Center(child: CircularProgressIndicator())),
    Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${widget.media['caption'] ?? ''}', style: const TextStyle(fontSize: 17)), Row(children: [TextButton.icon(onPressed: () => SharePlus.instance.share(ShareParams(text: '${widget.media['public_url']}')), icon: const Icon(Icons.share), label: const Text('Share')), TextButton.icon(onPressed: () => setState(() => saved = !saved), icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border), label: const Text('Save')), if (mine) TextButton.icon(onPressed: del, icon: const Icon(Icons.delete_outline), label: const Text('Delete'))])])),
  ])); }
}

class SearchTab extends StatefulWidget { const SearchTab({super.key}); @override State<SearchTab> createState() => _SearchTabState(); }
class _SearchTabState extends State<SearchTab> { final q = TextEditingController(); List<Map<String, dynamic>> results = []; bool busy = false;
  Future<void> search() async { final s = q.text.trim().toLowerCase(); if (s.isEmpty) return; setState(() => busy = true); try { final r = await sb.from('profiles').select().or('username_lower.ilike.%$s%,display_name.ilike.%$s%').limit(20); setState(() => results = List<Map<String, dynamic>>.from(r)); } catch (e) { if (mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); } }
  @override void dispose() { q.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Search')), body: ListView(padding: const EdgeInsets.all(16), children: [TextField(controller: q, onSubmitted: (_) => search(), decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search users, songs, effects...', suffixIcon: IconButton(onPressed: search, icon: const Icon(Icons.search)), border: const OutlineInputBorder())), const SizedBox(height: 14), if (busy) const Center(child: CircularProgressIndicator()), ...results.map((u) => ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text('${u['display_name'] ?? u['username'] ?? 'User'}'), subtitle: Text('@${u['username'] ?? ''}'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PublicProfilePage(uid: '${u['id']}'))))) ]));
}

class CreateTab extends StatelessWidget { const CreateTab({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
  const Text('Create', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
  _createTile(context, Icons.edit, "What's on your mind?", 'Post text with captions and privacy', const TextPostPage()),
  _createTile(context, Icons.camera_alt, 'Camera & Filters', 'Photo/video capture and filters', const CameraStudioPage()),
  _createTile(context, Icons.video_library, 'Upload video', 'Upload video to Supabase Storage', const MediaUploadPage(video: true)),
  _createTile(context, Icons.photo, 'Upload photo', 'Upload photo to Supabase Storage', const MediaUploadPage(video: false)),
  _createTile(context, Icons.music_note, 'Add music', 'Store audio in Supabase Storage', const MusicUploadPage()),
  _createTile(context, Icons.live_tv, 'Go Live', 'Live, reactions and gifts foundation', const LivePage()),
  _createTile(context, Icons.storefront, 'Creator Shop', 'Creator marketplace foundation', const ProductCreatePage()),
  Card(child: ListTile(leading: const Icon(Icons.auto_awesome), title: const Text('Laugh AI'), subtitle: const Text('AI captions, hashtags, ideas and creator tools'), onTap: () => showDialog(context: context, builder: (_) => const AlertDialog(title: Text('Laugh AI'), content: Text('AI tools are prepared for a secure backend connection.'))))),
 ]); }
Widget _createTile(BuildContext context, IconData icon, String title, String sub, Widget page) => Card(child: ListTile(leading: Icon(icon), title: Text(title), subtitle: Text(sub), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page))));
}

class TextPostPage extends StatefulWidget { const TextPostPage({super.key}); @override State<TextPostPage> createState() => _TextPostPageState(); }
class _TextPostPageState extends State<TextPostPage> { final c = TextEditingController(); String privacy = 'public'; bool busy = false; @override void dispose() { c.dispose(); super.dispose(); }
  Future<void> post() async { final u = sb.auth.currentUser; if (u == null || c.text.trim().isEmpty) return; setState(() => busy = true); try { final p = await sb.from('profiles').select('username,photo_url').eq('id', u.id).maybeSingle(); await sb.from('posts').insert({'owner_id': u.id, 'caption': c.text.trim(), 'privacy': privacy, 'username': p?['username'] ?? 'User', 'photo_url': p?['photo_url'] ?? '', 'created_at': DateTime.now().toIso8601String()}); if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Posted successfully.'))); Navigator.pop(context); } } catch (e) { if (mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); } }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("What's on your mind?")), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [TextField(controller: c, maxLines: 8, decoration: const InputDecoration(hintText: 'Share something...', border: OutlineInputBorder())), const SizedBox(height: 12), DropdownButtonFormField<String>(value: privacy, items: const [DropdownMenuItem(value: 'public', child: Text('Public')), DropdownMenuItem(value: 'friends', child: Text('Friends')), DropdownMenuItem(value: 'private', child: Text('Private'))], onChanged: (v) => setState(() => privacy = v!), decoration: const InputDecoration(labelText: 'Privacy', border: OutlineInputBorder())), const SizedBox(height: 16), SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : post, child: Text(busy ? 'Posting...' : 'Post'))]))));
}

class MediaUploadPage extends StatefulWidget { final bool video; const MediaUploadPage({super.key, required this.video}); @override State<MediaUploadPage> createState() => _MediaUploadPageState(); }
class _MediaUploadPageState extends State<MediaUploadPage> { File? file; final caption = TextEditingController(); String privacy = 'public'; bool busy = false;
  Future<void> pick() async { final r = await FilePicker.platform.pickFiles(type: widget.video ? FileType.video : FileType.image); if (r != null && r.files.single.path != null) setState(() => file = File(r.files.single.path!)); }
  Future<void> upload() async { if (file == null) return; setState(() => busy = true); try { final url = await uploadMedia(file!, widget.video ? 'videos' : 'photos'); await sb.from('media').insert({'owner_id': sb.auth.currentUser!.id, 'bucket_id': 'media', 'path': url.split('/media/').last, 'public_url': url, 'media_type': widget.video ? 'video' : 'photo', 'caption': caption.text.trim(), 'privacy': privacy, 'created_at': DateTime.now().toIso8601String()}); if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Uploaded successfully.'))); Navigator.pop(context); } } catch (e) { if (mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); } }
  @override void dispose() { caption.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.video ? 'Upload video' : 'Upload photo')), body: ListView(padding: const EdgeInsets.all(16), children: [OutlinedButton.icon(onPressed: pick, icon: Icon(widget.video ? Icons.video_library : Icons.photo), label: Text(file == null ? 'Choose from phone' : file!.path.split('/').last)), const SizedBox(height: 12), TextField(controller: caption, maxLines: 3, decoration: const InputDecoration(labelText: 'Caption / description', border: OutlineInputBorder())), const SizedBox(height: 12), DropdownButtonFormField<String>(value: privacy, items: const [DropdownMenuItem(value: 'public', child: Text('Public')), DropdownMenuItem(value: 'friends', child: Text('Friends')), DropdownMenuItem(value: 'private', child: Text('Private'))], onChanged: (v) => setState(() => privacy = v!), decoration: const InputDecoration(labelText: 'Privacy', border: OutlineInputBorder())), const SizedBox(height: 18), FilledButton(onPressed: file == null || busy ? null : upload, child: Text(busy ? 'Uploading...' : 'Upload'))]));
}

class CameraStudioPage extends StatefulWidget { const CameraStudioPage({super.key}); @override State<CameraStudioPage> createState() => _CameraStudioPageState(); }
class _CameraStudioPageState extends State<CameraStudioPage> { final picker = ImagePicker(); XFile? media; bool video = false; int filter = 0; bool busy = false; final names = ['Original', 'B&W', 'Warm', 'Cool', 'Vintage', 'Cinematic', 'Cartoon'];
  Future<void> take() async { final x = await picker.pickImage(source: ImageSource.camera, imageQuality: 92); if (x != null) setState(() { media = x; video = false; }); }
  Future<void> record() async { final x = await picker.pickVideo(source: ImageSource.camera, maxDuration: const Duration(minutes: 15)); if (x != null) setState(() { media = x; video = true; }); }
  Future<void> publish() async { if (media == null) return; setState(() => busy = true); try { final url = await uploadMedia(File(media!.path), video ? 'videos' : 'photos'); await sb.from('media').insert({'owner_id': sb.auth.currentUser!.id, 'bucket_id': 'media', 'path': url.split('/media/').last, 'public_url': url, 'media_type': video ? 'video' : 'photo', 'caption': '', 'privacy': 'public', 'created_at': DateTime.now().toIso8601String()}); if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Published successfully.'))); Navigator.pop(context); } } catch (e) { if (mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); } }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Camera & Filters')), body: ListView(padding: const EdgeInsets.all(16), children: [Container(height: 340, color: Colors.black, child: media == null ? const Center(child: Icon(Icons.camera_alt, color: Colors.white, size: 80)) : video ? const Center(child: Icon(Icons.videocam, color: Colors.white, size: 80)) : Image.file(File(media!.path), fit: BoxFit.cover)), const SizedBox(height: 14), Wrap(spacing: 8, children: [FilledButton.icon(onPressed: take, icon: const Icon(Icons.camera_alt), label: const Text('Take photo')), FilledButton.icon(onPressed: record, icon: const Icon(Icons.videocam), label: const Text('Record video'))]), const SizedBox(height: 12), const Text('Filters', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)), Wrap(spacing: 8, children: [for (int i = 0; i < names.length; i++) ChoiceChip(label: Text(names[i]), selected: filter == i, onSelected: (_) => setState(() => filter = i))]), const SizedBox(height: 18), FilledButton.icon(onPressed: media == null || busy ? null : publish, icon: const Icon(Icons.publish), label: Text(busy ? 'Publishing...' : 'Publish'))]));
}

class ChatTab extends StatelessWidget { const ChatTab({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Chat')), body: ListView(children: [ListTile(leading: const Icon(Icons.public), title: const Text('Community Chat'), subtitle: const Text('Realtime community messages'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CommunityChatPage()))), ListTile(leading: const Icon(Icons.lock), title: const Text('Private Chat'), subtitle: const Text('One-to-one messages with timestamps'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivateChatPage())))])); }

class CommunityChatPage extends StatefulWidget { const CommunityChatPage({super.key}); @override State<CommunityChatPage> createState() => _CommunityChatPageState(); }
class _CommunityChatPageState extends State<CommunityChatPage> { final c = TextEditingController(); List<Map<String, dynamic>> messages = [];
  @override void initState() { super.initState(); load(); }
  Future<void> load() async { try { final r = await sb.from('messages').select().eq('chat_type', 'community').order('created_at'); if (mounted) setState(() => messages = List<Map<String, dynamic>>.from(r)); } catch (_) {} }
  Future<void> send() async { if (c.text.trim().isEmpty) return; try { await sb.from('messages').insert({'sender_id': sb.auth.currentUser!.id, 'chat_type': 'community', 'body': c.text.trim(), 'created_at': DateTime.now().toIso8601String()}); c.clear(); load(); } catch (e) { if (mounted) await showError(context, e); } }
  @override void dispose() { c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Community Chat')), body: Column(children: [Expanded(child: ListView.builder(itemCount: messages.length, itemBuilder: (_, i) { final m = messages[i]; final mine = '${m['sender_id']}' == sb.auth.currentUser?.id; return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.all(6), padding: const EdgeInsets.all(10), decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: mine ? Colors.deepPurple.shade100 : Colors.grey.shade200), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('${m['body'] ?? ''}'), Text(timeText(m['created_at']), style: const TextStyle(fontSize: 10))]))); })), SafeArea(child: Row(children: [Expanded(child: TextField(controller: c, decoration: const InputDecoration(hintText: 'Message...'))), IconButton(onPressed: send, icon: const Icon(Icons.send))]))]));
}

class PrivateChatPage extends StatefulWidget { const PrivateChatPage({super.key}); @override State<PrivateChatPage> createState() => _PrivateChatPageState(); }
class _PrivateChatPageState extends State<PrivateChatPage> { final c = TextEditingController(); final target = TextEditingController(); List<Map<String, dynamic>> messages = [];
  Future<void> load() async { if (target.text.trim().isEmpty) return; try { final r = await sb.from('messages').select().or('sender_id.eq.${sb.auth.currentUser!.id},recipient_id.eq.${sb.auth.currentUser!.id}').order('created_at'); if (mounted) setState(() => messages = List<Map<String, dynamic>>.from(r)); } catch (_) {} }
  Future<void> send() async { if (c.text.trim().isEmpty || target.text.trim().isEmpty) return; try { await sb.from('messages').insert({'sender_id': sb.auth.currentUser!.id, 'recipient_id': target.text.trim(), 'chat_type': 'private', 'body': c.text.trim(), 'created_at': DateTime.now().toIso8601String()}); c.clear(); load(); } catch (e) { if (mounted) await showError(context, e); } }
  @override void dispose() { c.dispose(); target.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Private Chat')), body: Column(children: [Padding(padding: const EdgeInsets.all(8), child: Row(children: [Expanded(child: TextField(controller: target, decoration: const InputDecoration(labelText: 'Recipient user ID', border: OutlineInputBorder()))), IconButton(onPressed: load, icon: const Icon(Icons.refresh))])), Expanded(child: ListView.builder(itemCount: messages.length, itemBuilder: (_, i) { final m = messages[i]; final mine = '${m['sender_id']}' == sb.auth.currentUser?.id; return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.all(6), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: mine ? Colors.deepPurple.shade100 : Colors.grey.shade200, borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('${m['body'] ?? ''}'), Text(timeText(m['created_at']), style: const TextStyle(fontSize: 10))]))); })), SafeArea(child: Row(children: [Expanded(child: TextField(controller: c, decoration: const InputDecoration(hintText: 'Message...'))), IconButton(onPressed: send, icon: const Icon(Icons.send))]))]));
}

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>?>(
      future: sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle(),
      builder: (context, snapshot) {
        final p = snapshot.data ?? <String, dynamic>{};
        return Scaffold(
          appBar: AppBar(
            title: const Text('Profile'),
            actions: [
              IconButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsPage()),
                ),
                icon: const Icon(Icons.settings),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const CircleAvatar(radius: 55, child: Icon(Icons.person, size: 55)),
              const SizedBox(height: 10),
              Text(
                '${p['display_name'] ?? p['username'] ?? 'User'}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              Text('@${p['username'] ?? ''}', textAlign: TextAlign.center),
              const SizedBox(height: 12),
              Text('${p['bio'] ?? ''}', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const EditProfilePage()),
                ),
                icon: const Icon(Icons.edit),
                label: const Text('Edit profile'),
              ),
              OutlinedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const NotificationsPage()),
                ),
                icon: const Icon(Icons.notifications),
                label: const Text('Notifications'),
              ),
            ],
          ),
        );
      },
    );
  }
}
class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> { final display = TextEditingController(), username = TextEditingController(), bio = TextEditingController(); bool busy = false;
  @override void initState() { super.initState(); load(); }
  Future<void> load() async { final p = await sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle(); if (p != null) { display.text = '${p['display_name'] ?? ''}'; username.text = '${p['username'] ?? ''}'; bio.text = '${p['bio'] ?? ''}'; } }
  Future<void> save() async { final u = sb.auth.currentUser; if (u == null) return; setState(() => busy = true); try { await sb.from('profiles').upsert({'id': u.id, 'display_name': display.text.trim(), 'username': username.text.trim(), 'username_lower': username.text.trim().toLowerCase(), 'bio': bio.text.trim()}); if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile saved.'))); Navigator.pop(context); } } catch (e) { if (mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); } }
  @override void dispose() { display.dispose(); username.dispose(); bio.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Edit Profile')), body: ListView(padding: const EdgeInsets.all(16), children: [TextField(controller: display, decoration: const InputDecoration(labelText: 'Display name', border: OutlineInputBorder())), const SizedBox(height: 10), TextField(controller: username, decoration: const InputDecoration(labelText: 'Username', prefixText: '@', border: OutlineInputBorder())), const SizedBox(height: 10), TextField(controller: bio, maxLines: 4, decoration: const InputDecoration(labelText: 'Bio', border: OutlineInputBorder())), const SizedBox(height: 18), FilledButton(onPressed: busy ? null : save, child: Text(busy ? 'Saving...' : 'Save profile'))]));
}

class PublicProfilePage extends StatelessWidget {
  final String uid;
  const PublicProfilePage({super.key, required this.uid});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>?>(
      future: sb.from('profiles').select().eq('id', uid).maybeSingle(),
      builder: (context, snapshot) {
        final p = snapshot.data ?? <String, dynamic>{};
        return Scaffold(
          appBar: AppBar(title: Text('@${p['username'] ?? ''}')),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const CircleAvatar(radius: 50, child: Icon(Icons.person, size: 50)),
              const SizedBox(height: 10),
              Text(
                '${p['display_name'] ?? 'User'}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              Text('${p['bio'] ?? ''}', textAlign: TextAlign.center),
              const SizedBox(height: 14),
              FilledButton(
                onPressed: () async {
                  try {
                    await sb.from('follows').upsert({
                      'follower_id': sb.auth.currentUser!.id,
                      'following_id': uid,
                    });
                    await notifyUser(uid, 'follow', 'New follower', 'Someone followed you.', uid);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Following.')),
                      );
                    }
                  } catch (e) {
                    if (context.mounted) await showError(context, e);
                  }
                },
                child: const Text('Follow'),
              ),
              OutlinedButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const PrivateChatPage()),
                ),
                child: const Text('Message'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: sb
            .from('notifications')
            .select()
            .eq('user_id', sb.auth.currentUser!.id)
            .order('created_at', ascending: false),
        builder: (context, snapshot) {
          final rows = snapshot.data ?? <Map<String, dynamic>>[];
          if (rows.isEmpty) {
            return const Center(child: Text('No notifications yet.'));
          }
          return ListView(
            children: rows.map<Widget>((n) {
              return ListTile(
                leading: const Icon(Icons.notifications),
                title: Text('${n['title'] ?? ''}'),
                subtitle: Text('${n['body'] ?? ''}'),
                trailing: Text(timeText(n['created_at'])),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

class SettingsPage extends StatelessWidget { const SettingsPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Settings')), body: ListView(children: [ListTile(leading: const Icon(Icons.logout), title: const Text('Log out'), onTap: () async { await sb.auth.signOut(); }), const ListTile(leading: Icon(Icons.lock), title: Text('Privacy & Safety'), subtitle: Text('Control account and content privacy')), const ListTile(leading: Icon(Icons.account_balance_wallet), title: Text('Creator Wallet'), subtitle: Text('Prepared for creator earnings and gifts')), const ListTile(leading: Icon(Icons.live_tv), title: Text('Live'), subtitle: Text('Realtime broadcast + moderation + gifts')), const ListTile(leading: Icon(Icons.call), title: Text('Voice & Video Calls'), subtitle: Text('Realtime signaling/media layer'))])); }
}

class LivePage extends StatelessWidget { const LivePage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Go Live')), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.live_tv, size: 90), const Text('Live', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('Supabase handles the account, database, storage and realtime data foundation. Camera broadcast still needs a WebRTC/media server.'), const SizedBox(height: 18), FilledButton(onPressed: () => showDialog(context: context, builder: (_) => const AlertDialog(title: Text('Live setup'), content: Text('Next live layer: WebRTC/media server, moderation, viewer reactions and creator gift wallet.'))), child: const Text('Start Live'))])))); }
}

class MusicUploadPage extends StatefulWidget { const MusicUploadPage({super.key}); @override State<MusicUploadPage> createState() => _MusicUploadPageState(); }
class _MusicUploadPageState extends State<MusicUploadPage> { PlatformFile? file; final title = TextEditingController(); bool busy = false;
  Future<void> pick() async { final r = await FilePicker.platform.pickFiles(type: FileType.audio); if (r != null && r.files.single.path != null) setState(() => file = r.files.single); }
  Future<void> upload() async { if (file?.path == null) return; setState(() => busy = true); try { final url = await uploadMedia(File(file!.path!), 'music', contentType: 'audio/mpeg'); await sb.from('media').insert({'owner_id': sb.auth.currentUser!.id, 'bucket_id': 'media', 'path': url.split('/media/').last, 'public_url': url, 'media_type': 'audio', 'caption': title.text.trim(), 'privacy': 'public', 'created_at': DateTime.now().toIso8601String()}); if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Music uploaded successfully.'))); Navigator.pop(context); } } catch (e) { if (mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); } }
  @override void dispose() { title.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Add Music')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [OutlinedButton.icon(onPressed: pick, icon: const Icon(Icons.audio_file), label: Text(file?.name ?? 'Choose audio')), const SizedBox(height: 12), TextField(controller: title, decoration: const InputDecoration(labelText: 'Song title', border: OutlineInputBorder())), const SizedBox(height: 16), FilledButton(onPressed: file == null || busy ? null : upload, child: Text(busy ? 'Uploading...' : 'Add to music library'))])));
}

class ProductCreatePage extends StatefulWidget { const ProductCreatePage({super.key}); @override State<ProductCreatePage> createState() => _ProductCreatePageState(); }
class _ProductCreatePageState extends State<ProductCreatePage> { final title = TextEditingController(), price = TextEditingController(); String type = 'song'; bool busy = false;
  Future<void> publish() async { final u = sb.auth.currentUser; if (u == null || title.text.trim().isEmpty) return; setState(() => busy = true); try { await sb.from('products').insert({'owner_id': u.id, 'title': title.text.trim(), 'price': price.text.trim(), 'type': type, 'published': true}); if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Item added to your shop.'))); Navigator.pop(context); } } catch (e) { if (mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); } }
  @override void dispose() { title.dispose(); price.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Creator Shop')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'Music or film title', border: OutlineInputBorder())), const SizedBox(height: 12), DropdownButtonFormField<String>(value: type, items: const [DropdownMenuItem(value: 'song', child: Text('Song')), DropdownMenuItem(value: 'album', child: Text('Album')), DropdownMenuItem(value: 'film', child: Text('Full film'))], onChanged: (v) => setState(() => type = v!), decoration: const InputDecoration(labelText: 'Type', border: OutlineInputBorder())), const SizedBox(height: 12), TextField(controller: price, decoration: const InputDecoration(labelText: 'Price', hintText: 'e.g. 5000 UGX', border: OutlineInputBorder())), const SizedBox(height: 18), FilledButton(onPressed: busy ? null : publish, child: Text(busy ? 'Publishing...' : 'Publish'))])));
}
