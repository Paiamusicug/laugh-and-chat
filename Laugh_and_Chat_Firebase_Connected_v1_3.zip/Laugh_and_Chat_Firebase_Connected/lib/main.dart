import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const LaughAndChatApp());
}

class LaughAndChatApp extends StatelessWidget {
  const LaughAndChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Laugh & Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        return snapshot.data == null ? const AuthPage() : const HomePage();
      },
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final phoneController = TextEditingController();
  final codeController = TextEditingController();

  bool createAccount = false;
  bool busy = false;
  bool phoneMode = false;
  bool codeMode = false;
  String error = '';
  String? verificationId;
  int? resendToken;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    phoneController.dispose();
    codeController.dispose();
    super.dispose();
  }

  Future<void> submitEmail() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    if (email.isEmpty || password.length < 6) {
      setState(() => error = 'Enter an email and a password of at least 6 characters.');
      return;
    }

    setState(() {
      busy = true;
      error = '';
    });
    try {
      if (createAccount) {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email,
          password: password,
        );
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email,
          password: password,
        );
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? e.code);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> sendPhoneCode() async {
    final phone = phoneController.text.trim();
    if (phone.isEmpty || !phone.startsWith('+')) {
      setState(() => error = 'Enter your phone number with country code, e.g. +256700000000.');
      return;
    }

    setState(() {
      busy = true;
      error = '';
    });

    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone,
      timeout: const Duration(seconds: 60),
      forceResendingToken: resendToken,
      verificationCompleted: (PhoneAuthCredential credential) async {
        try {
          await FirebaseAuth.instance.signInWithCredential(credential);
        } on FirebaseAuthException catch (e) {
          if (mounted) setState(() => error = e.message ?? e.code);
        }
      },
      verificationFailed: (FirebaseAuthException e) {
        if (mounted) {
          setState(() {
            busy = false;
            error = e.message ?? e.code;
          });
        }
      },
      codeSent: (String id, int? token) {
        if (mounted) {
          setState(() {
            verificationId = id;
            resendToken = token;
            codeMode = true;
            busy = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Verification code sent.')),
          );
        }
      },
      codeAutoRetrievalTimeout: (String id) {
        verificationId = id;
        if (mounted) setState(() => busy = false);
      },
    );
  }

  Future<void> verifyPhoneCode() async {
    final code = codeController.text.trim();
    if (verificationId == null || code.length < 4) {
      setState(() => error = 'Enter the SMS verification code.');
      return;
    }

    setState(() {
      busy = true;
      error = '';
    });
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!,
        smsCode: code,
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? e.code);
    } catch (e) {
      setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void switchAuthMode() {
    setState(() {
      phoneMode = !phoneMode;
      codeMode = false;
      error = '';
      busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.emoji_emotions, size: 82),
                const SizedBox(height: 12),
                const Text(
                  'Laugh & Chat',
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                ),
                const Text('Connect • Chat • Laugh • Share'),
                const SizedBox(height: 30),
                if (!phoneMode) ..._emailFields() else ..._phoneFields(),
                const SizedBox(height: 12),
                if (error.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(
                      error,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  ),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: busy
                        ? null
                        : (!phoneMode
                            ? submitEmail
                            : (codeMode ? verifyPhoneCode : sendPhoneCode)),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Text(
                        busy
                            ? 'Please wait...'
                            : (!phoneMode
                                ? (createAccount ? 'Create account' : 'Log in')
                                : (codeMode ? 'Verify code' : 'Send SMS code')),
                      ),
                    ),
                  ),
                ),
                if (!phoneMode) ...[
                  TextButton(
                    onPressed: () => setState(() {
                      createAccount = !createAccount;
                      error = '';
                    }),
                    child: Text(createAccount
                        ? 'Already have an account? Log in'
                        : 'New here? Create an account'),
                  ),
                  TextButton(
                    onPressed: () async {
                      final email = emailController.text.trim();
                      if (email.isEmpty) {
                        setState(() => error = 'Enter your email address first.');
                        return;
                      }
                      try {
                        await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Password reset email sent.')),
                          );
                        }
                      } on FirebaseAuthException catch (e) {
                        setState(() => error = e.message ?? e.code);
                      }
                    },
                    child: const Text('Forgot password?'),
                  ),
                ],
                const Divider(height: 30),
                OutlinedButton.icon(
                  onPressed: busy ? null : switchAuthMode,
                  icon: Icon(phoneMode ? Icons.email : Icons.phone),
                  label: Text(phoneMode ? 'Use email instead' : 'Continue with phone'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _emailFields() => [
        TextField(
          controller: emailController,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(
            labelText: 'Email address',
            prefixIcon: Icon(Icons.email),
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: passwordController,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Password',
            prefixIcon: Icon(Icons.lock),
            border: OutlineInputBorder(),
          ),
        ),
      ];

  List<Widget> _phoneFields() => [
        if (!codeMode)
          TextField(
            controller: phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Phone number with country code',
              hintText: '+256700000000',
              prefixIcon: Icon(Icons.phone),
              border: OutlineInputBorder(),
            ),
          )
        else ...[
          TextField(
            controller: phoneController,
            readOnly: true,
            decoration: const InputDecoration(
              labelText: 'Phone number',
              prefixIcon: Icon(Icons.phone),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: codeController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'SMS verification code',
              prefixIcon: Icon(Icons.sms),
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ];
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    _HomeTab(),
    _SimpleTab(icon: Icons.upload, title: 'Upload', message: 'Video uploading will be connected next.'),
    _SimpleTab(icon: Icons.chat, title: 'Chat', message: 'Chat is ready for the next Firebase step.'),
    _SimpleTab(icon: Icons.notifications, title: 'Notifications', message: 'Notifications will appear here.'),
    _ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Laugh & Chat'),
        actions: [
          IconButton(
            tooltip: 'Log out',
            onPressed: () => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.upload), label: 'Upload'),
          NavigationDestination(icon: Icon(Icons.chat), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.notifications), label: 'Alerts'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: 5,
      itemBuilder: (_, i) => Card(
        margin: const EdgeInsets.only(bottom: 16),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 220,
              width: double.infinity,
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              child: const Center(child: Icon(Icons.play_circle_fill, size: 72)),
            ),
            const ListTile(
              leading: CircleAvatar(child: Icon(Icons.person)),
              title: Text('@comedian'),
              subtitle: Text('Welcome to Laugh & Chat! 😂'),
              trailing: Icon(Icons.favorite_border),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Text('Like • Comment • Share'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SimpleTab extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;

  const _SimpleTab({required this.icon, required this.title, required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 72),
            const SizedBox(height: 16),
            Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class _ProfileTab extends StatelessWidget {
  const _ProfileTab();

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircleAvatar(radius: 44, child: Icon(Icons.person, size: 46)),
          const SizedBox(height: 16),
          Text(user?.email ?? user?.phoneNumber ?? 'Laugh & Chat user'),
          const SizedBox(height: 8),
          const Text('Profile • Followers • Favorites coming next'),
        ],
      ),
    );
  }
}
