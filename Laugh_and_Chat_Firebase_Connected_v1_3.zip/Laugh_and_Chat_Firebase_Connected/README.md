# Laugh & Chat — Firebase Connected v1.3

This package contains the updated Flutter app source for Laugh & Chat.

## Firebase configuration
The included `android/app/google-services.json` is the Firebase configuration for the Android app with package name:
`com.humblet.laughandchat`

Firebase project ID: `laugh-and-chat`

## Authentication included
- Email/password account creation and login
- Password reset email
- Real phone-number login with Firebase SMS verification
- Auth state gate
- Logout

## Important Firebase setup already completed
In the Firebase Console, the Android app has SHA-1 fingerprint:
`42:BA:C5:8C:15:A0:51:81:DA:91:DC:23:67:C8:CB:FE:68:E6:B8:45`

Phone sign-in must be enabled in Firebase Authentication > Sign-in method.

## Build
This is Flutter source. On a computer with Flutter installed, run:

    flutter pub get
    flutter run

For Android Studio/Flutter tooling, use the package name `com.humblet.laughandchat`.

## Phone login
Enter a full international phone number, for example `+256700000000`, request the SMS code, then enter the code.

Firebase's new projects may have a daily SMS quota until billing is configured. Do not treat the quota warning as an app error.

## Next development steps
1. Connect Firestore user profiles.
2. Add video upload/storage and a real feed.
3. Add likes, comments, shares, follows and favorites.
4. Add one-to-one and group chat.
5. Add notifications and moderation/reporting.
6. Add translation.
7. Add Google sign-in and Apple sign-in.
8. Prepare Android release signing and iOS configuration.
