# Laugh & Chat v2.1.1

Major upgrade foundation for the Laugh & Chat social platform.

## Included
- Branded Laugh & Chat logo in the app and launcher-ready asset.
- Email/password and phone authentication.
- Email verification and verified-badge request flow.
- Home video feed with emoji reactions, save, repost, share and download-to-gallery.
- Short-video and full-film upload with public/private/friends/followers privacy choices.
- Photo posts, stories, text posts ("What's on your mind?"), camera and filters.
- Photo filter baking and editor foundation.
- Music upload from phone.
- Search foundation for users/videos/songs/effects/films.
- Private chat by username, group chat member-add UI, message timestamps and sent/received bubbles.
- Profile cover photo, profile photo, bio and YouTube/Facebook/Instagram/TikTok links.
- Follow/subscribe profile actions.
- Real Firestore notification screen foundation.
- Logout and settings.
- Creator marketplace/premiere/live screens prepared for backend payment/media integrations.

## Important Firebase setup
1. In Firebase Console, open **Storage** and click **Get started** if Storage has not been enabled yet. The previous object-not-found upload errors can occur when Storage is not ready.
2. Deploy the included `storage.rules` and `firestore.rules` (Firebase CLI: `firebase deploy --only storage,firestore`).
3. Keep the existing `google-services.json` in `android/app/`.
4. Email/Phone Authentication providers must remain enabled.
5. For production, replace the starter Firestore rules with stricter per-user/private-content rules before public launch.

## Features that need a server/provider before they can be truly live
- AI/OpenAI media transformations: secure backend required; never ship an API key in the APK.
- Real voice/video calls: WebRTC signaling/media backend required.
- Live streaming: realtime media streaming backend required.
- Mobile-money/card checkout and creator payouts: payment provider + secure server/webhook required.
- Full video export/editing (trim, music, transitions) needs native media processing.

The app UI and Firestore/Storage foundations for these features are included so they can be connected without redesigning the app.


## Version 2.1.1 fixes
- Clear Like, Repost, Share and Download actions on video cards.
- Home feed empty state now provides a direct upload button.
- Video upload/download/share operations have stronger error handling and timeouts.
- Text posts no longer wait forever on a stuck Firestore request.
- Video cards show a clear unavailable state when a video URL cannot load.
- Firebase Storage download URL retrieval has a timeout.
- Uploads now attach the correct media content type and verify the uploaded object before creating the Firestore feed record.
- Storage errors now give a clearer setup message instead of leaving the user guessing.
- Android versionCode/versionName are synchronized so the new build is actually a newer version.
- Home empty state has direct video and camera actions.


## v2.2.0 — Storage-free social core
- Core social feed now supports Firestore text posts even when Firebase Storage is unavailable.
- Added visible Like, Comment, Repost, Share and Download action buttons to text posts.
- Comments are stored under each post/video in Firestore.
- Video/photo/story/music/profile upload entry points now explain that Firebase Storage is required instead of producing an object-not-found error.
- Storage can be enabled later without replacing the social core.
