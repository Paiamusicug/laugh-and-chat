import 'dart:io';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:gallery_saver_plus/gallery_saver.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

const appName = 'Laugh & Chat';
const reactions = ['❤️','😂','😍','😮','😢','😡','👍','👏'];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const LaughAndChatApp());
}

class LaughAndChatApp extends StatelessWidget {
  const LaughAndChatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: appName,
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple), useMaterial3: true),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return snapshot.data == null ? const AuthPage() : const HomePage();
    },
  );
}

class AppLogo extends StatelessWidget {
  final double size;
  const AppLogo({super.key, this.size = 68});
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(size * .22),
    child: Image.asset('assets/logo.png', width: size, height: size, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(width: size, height: size, decoration: BoxDecoration(color: Colors.deepPurple, borderRadius: BorderRadius.circular(size*.22)), child: const Icon(Icons.emoji_emotions, color: Colors.white, size: 42))),
  );
}

Future<void> showError(BuildContext context, Object e) async {
  if (!context.mounted) return;
  await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Something went wrong'), content: Text(e.toString()), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));
}

Future<String?> uploadFile(File file, String path) async {
  final ref = FirebaseStorage.instance.ref(path);
  final task = ref.putFile(file);
  final snap = await task;
  return snap.state == TaskState.success ? ref.getDownloadURL() : null;
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final phone = TextEditingController();
  final code = TextEditingController();
  bool create = false;
  bool phoneMode = false;
  bool codeMode = false;
  bool busy = false;
  String error = '';
  String? verificationId;
  int? resendToken;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    phone.dispose();
    code.dispose();
    super.dispose();
  }

  Future<void> submitEmail() async {
    if (email.text.trim().isEmpty || password.text.length < 6) {
      setState(() => error = 'Enter a valid email and password (6+ characters).');
      return;
    }
    setState(() => busy = true);
    try {
      UserCredential c;
      if (create) {
        c = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
        await c.user?.sendEmailVerification();
      } else {
        c = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(),
          password: password.text,
        );
      }
      final u = c.user;
      if (u != null) {
        await FirebaseFirestore.instance.collection('users').doc(u.uid).set({
          'email': u.email,
          'displayName': u.displayName ?? '',
          'username': '',
          'usernameLower': '',
          'bio': '',
          'photoUrl': u.photoURL ?? '',
          'coverUrl': '',
          'followersCount': 0,
          'followingCount': 0,
          'subscribersCount': 0,
          'createdAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() => error = e.message ?? e.code);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> sendCode() async {
    if (!phone.text.trim().startsWith('+')) {
      setState(() => error = 'Use international format, e.g. +256700000000');
      return;
    }
    setState(() => busy = true);
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone.text.trim(),
      timeout: const Duration(seconds: 60),
      forceResendingToken: resendToken,
      verificationCompleted: (credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
      },
      verificationFailed: (e) {
        if (mounted) setState(() => error = e.message ?? e.code);
      },
      codeSent: (id, token) {
        if (mounted) {
          setState(() {
            verificationId = id;
            resendToken = token;
            codeMode = true;
            busy = false;
          });
        }
      },
      codeAutoRetrievalTimeout: (id) {
        verificationId = id;
        if (mounted) setState(() => busy = false);
      },
    );
  }

  Future<void> verify() async {
    if (verificationId == null || code.text.trim().length < 4) {
      setState(() => error = 'Enter the SMS code.');
      return;
    }
    setState(() => busy = true);
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!,
        smsCode: code.text.trim(),
      );
      final c = await FirebaseAuth.instance.signInWithCredential(credential);
      final u = c.user;
      if (u != null) {
        await FirebaseFirestore.instance.collection('users').doc(u.uid).set({
          'phoneNumber': u.phoneNumber,
        }, SetOptions(merge: true));
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) setState(() => error = e.message ?? e.code);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final emailFields = <Widget>[
      TextField(
        controller: email,
        keyboardType: TextInputType.emailAddress,
        decoration: const InputDecoration(
          labelText: 'Email address',
          prefixIcon: Icon(Icons.email),
          border: OutlineInputBorder(),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: password,
        obscureText: true,
        decoration: const InputDecoration(
          labelText: 'Password',
          prefixIcon: Icon(Icons.lock),
          border: OutlineInputBorder(),
        ),
      ),
    ];

    final phoneFields = <Widget>[
      if (!codeMode)
        TextField(
          controller: phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(
            labelText: 'Phone number',
            hintText: '+256700000000',
            prefixIcon: Icon(Icons.phone),
            border: OutlineInputBorder(),
          ),
        )
      else ...[
        TextField(
          controller: phone,
          readOnly: true,
          decoration: const InputDecoration(
            labelText: 'Phone number',
            prefixIcon: Icon(Icons.phone),
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: code,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'SMS verification code',
            prefixIcon: Icon(Icons.sms),
            border: OutlineInputBorder(),
          ),
        ),
      ],
    ];

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                const AppLogo(size: 110),
                const SizedBox(height: 12),
                const Text(
                  appName,
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                ),
                const Text('Connect • Chat • Create • Enjoy'),
                const SizedBox(height: 24),
                if (!phoneMode) ...emailFields else ...phoneFields,
                if (error.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      error,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  ),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: busy
                        ? null
                        : (!phoneMode ? submitEmail : (codeMode ? verify : sendCode)),
                    child: Padding(
                      padding: const EdgeInsets.all(13),
                      child: Text(
                        busy
                            ? 'Please wait...'
                            : (!phoneMode
                                ? (create ? 'Create account' : 'Log in')
                                : (codeMode ? 'Verify code' : 'Send SMS code')),
                      ),
                    ),
                  ),
                ),
                if (!phoneMode) ...[
                  TextButton(
                    onPressed: () => setState(() => create = !create),
                    child: Text(
                      create
                          ? 'Already have an account? Log in'
                          : 'New here? Create an account',
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      if (email.text.trim().isEmpty) {
                        setState(() => error = 'Enter your email first.');
                        return;
                      }
                      try {
                        await FirebaseAuth.instance.sendPasswordResetEmail(
                          email: email.text.trim(),
                        );
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Password reset email sent.')),
                          );
                        }
                      } catch (e) {
                        if (mounted) setState(() => error = e.toString());
                      }
                    },
                    child: const Text('Forgot password?'),
                  ),
                ],
                const Divider(height: 30),
                OutlinedButton.icon(
                  onPressed: busy
                      ? null
                      : () => setState(() {
                            phoneMode = !phoneMode;
                            codeMode = false;
                            error = '';
                          }),
                  icon: Icon(phoneMode ? Icons.email : Icons.phone),
                  label: Text(phoneMode ? 'Use email instead' : 'Continue with phone'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage>{int index=0;late final List<Widget> pages;@override void initState(){super.initState();pages=[const FeedTab(),const SearchTab(),const CreateTab(),const ChatTab(),const ProfileTab()];}
  Future<void>logout()async{final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Log out?'),content:const Text('You can sign in again anytime.'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Log out'))]));if(ok==true)await FirebaseAuth.instance.signOut();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Row(children:[const AppLogo(size:38),const SizedBox(width:10),const Text(appName)]),actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CameraStudioPage())),icon:const Icon(Icons.camera_alt)),IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AlertsPage())),icon:const Icon(Icons.notifications)),PopupMenuButton<String>(onSelected:(v){if(v=='logout')logout();if(v=='settings')Navigator.push(context,MaterialPageRoute(builder:(_)=>const SettingsPage()));},itemBuilder:(_)=>const [PopupMenuItem(value:'settings',child:Text('Settings')),PopupMenuItem(value:'logout',child:Text('Logout'))])]),body:pages[index],bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const [NavigationDestination(icon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.search),label:'Search'),NavigationDestination(icon:Icon(Icons.add_box),label:'Create'),NavigationDestination(icon:Icon(Icons.chat),label:'Chat'),NavigationDestination(icon:Icon(Icons.person),label:'Profile')]));}

class FeedTab extends StatelessWidget{const FeedTab({super.key});@override Widget build(BuildContext context)=>RefreshIndicator(onRefresh:()async{},child:StreamBuilder<QuerySnapshot>(stream:FirebaseFirestore.instance.collection('videos').where('privacy',isEqualTo:'public').limit(50).snapshots(),builder:(c,s){if(s.hasError)return ListView(children:[Padding(padding:const EdgeInsets.all(20),child:Text('Home feed error: ${s.error}'))]);if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.docs.isEmpty)return ListView(children:[const SizedBox(height:50),const Icon(Icons.video_library_outlined,size:70),const SizedBox(height:12),const Center(child:Text('No public videos yet. Be the first to upload!'))]);return ListView.builder(padding:const EdgeInsets.all(10),itemCount:s.data!.docs.length,itemBuilder:(c,i)=>VideoCard(doc:s.data!.docs[i]));}));}

class VideoCard extends StatefulWidget{final DocumentSnapshot doc;const VideoCard({super.key,required this.doc});@override State<VideoCard>createState()=>_VideoCardState();}
class _VideoCardState extends State<VideoCard>{VideoPlayerController? controller;String? myReaction;bool saved=false,working=false;@override void initState(){super.initState();final d=widget.doc.data()as Map<String,dynamic>;final url=d['videoUrl']as String?;if(url!=null&&url.isNotEmpty){controller=VideoPlayerController.networkUrl(Uri.parse(url))..initialize().then((_){if(mounted)setState((){});});}myReaction=(d['reactionsByUser']as Map?)?[FirebaseAuth.instance.currentUser?.uid];}
@override void dispose(){controller?.dispose();super.dispose();}
Future<void>react(String emoji)async{final u=FirebaseAuth.instance.currentUser;if(u==null)return;setState(()=>working=true);final ref=widget.doc.reference;final d=widget.doc.data()as Map<String,dynamic>;final map=Map<String,dynamic>.from(d['reactionCounts']??{});final users=Map<String,dynamic>.from(d['reactionsByUser']??{});final old=users[u.uid];if(old==emoji){users.remove(u.uid);map[emoji]=((map[emoji]??0)as num).toInt()-1;}else{if(old!=null)map[old]=((map[old]??1)as num).toInt()-1;users[u.uid]=emoji;map[emoji]=((map[emoji]??0)as num).toInt()+1;}await ref.update({'reactionCounts':map,'reactionsByUser':users,'likes':map['❤️']??0});if(mounted)setState(() {myReaction=old==emoji?null:emoji;working=false;});}
Future<void>save()async{final u=FirebaseAuth.instance.currentUser;if(u==null)return;await FirebaseFirestore.instance.collection('users').doc(u.uid).collection('saved').doc(widget.doc.id).set({'videoId':widget.doc.id,'savedAt':FieldValue.serverTimestamp()});setState(()=>saved=true);}
Future<void>repost()async{final u=FirebaseAuth.instance.currentUser;if(u==null)return;await FirebaseFirestore.instance.collection('reposts').add({'videoId':widget.doc.id,'uid':u.uid,'createdAt':FieldValue.serverTimestamp()});if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Reposted.')));}
Future<void>download()async{final d=widget.doc.data()as Map<String,dynamic>;final url=d['videoUrl']as String?;if(url==null)return;final ok=await GallerySaver.saveVideo(url);if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(ok==true?'Saved to gallery.':'Could not save video.')));}
@override Widget build(BuildContext context){final d=widget.doc.data()as Map<String,dynamic>;final counts=Map<String,dynamic>.from(d['reactionCounts']??{});final total=counts.values.fold<int>(0,(a,b)=>a+(b is num?b.toInt():0));return Card(clipBehavior:Clip.antiAlias,margin:const EdgeInsets.only(bottom:18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[if(controller!=null&&controller!.value.isInitialized)GestureDetector(onTap:(){setState(()=>controller!.value.isPlaying?controller!.pause():controller!.play());},child:AspectRatio(aspectRatio:controller!.value.aspectRatio,child:VideoPlayer(controller!)))else Container(height:240,color:Colors.black,child:const Center(child:Icon(Icons.play_circle,color:Colors.white,size:70))),ListTile(leading:CircleAvatar(child:const Icon(Icons.person)),title:Text(d['username']??'Creator'),subtitle:Text(d['caption']??'')),Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:Wrap(spacing:4,children:[for(final r in reactions)TextButton(onPressed:working?null:()=>react(r),child:Text('$r ${counts[r]??0}'))])),Padding(padding:const EdgeInsets.fromLTRB(12,0,12,10),child:Row(children:[Text('$total reactions'),const Spacer(),IconButton(onPressed:save,icon:Icon(saved?Icons.bookmark:Icons.bookmark_border)),IconButton(onPressed:repost,icon:const Icon(Icons.repeat)),IconButton(onPressed:download,icon:const Icon(Icons.download)),IconButton(onPressed:()async{await SharePlus.instance.share(ShareParams(text:d['videoUrl']?.toString()??''));},icon:const Icon(Icons.share))]))]));}
}

class SearchTab extends StatefulWidget{const SearchTab({super.key});@override State<SearchTab>createState()=>_SearchTabState();}
class _SearchTabState extends State<SearchTab> {
  final q = TextEditingController();
  String type = 'Users';
  @override void dispose() { q.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final query = q.text.trim().toLowerCase();
    return ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: q, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search users, videos, songs, effects...', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      Wrap(spacing: 8, children: [for (final x in ['Users','Videos','Songs','Effects','Films']) ChoiceChip(label: Text(x), selected: type == x, onSelected: (_) => setState(() => type = x))]),
      const SizedBox(height: 12),
      if (query.isEmpty) const Card(child: ListTile(leading: Icon(Icons.auto_awesome), title: Text('Search effects, users, songs and more'), subtitle: Text('Try a username, title, hashtag or effect name.')))
      else if (type == 'Users') StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('users').where('usernameLower', isGreaterThanOrEqualTo: query).where('usernameLower', isLessThanOrEqualTo: '${query}\uf8ff').limit(20).snapshots(),
        builder: (c, s) {
          if (s.hasError) return Text('Search error: ${s.error}');
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          return Column(children: s.data!.docs.map((d) {
            final data = d.data() as Map<String, dynamic>;
            final photo = (data['photoUrl'] ?? '').toString();
            return ListTile(leading: CircleAvatar(backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null, child: photo.isEmpty ? const Icon(Icons.person) : null), title: Text((data['displayName'] ?? 'User').toString()), subtitle: Text('@${data['username'] ?? ''}'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PublicProfilePage(uid: d.id))));
          }).toList());
        },
      )
      else const Card(child: ListTile(leading: Icon(Icons.search), title: Text('Search'), subtitle: Text('Search index for this category is ready.'))),
    ]);
  }
}

class CreateTab extends StatelessWidget {
  const CreateTab({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Create', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
    Card(child: ListTile(leading: const Icon(Icons.camera_alt), title: const Text('Camera & Effects'), subtitle: const Text('Take photos or record videos'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CameraStudioPage())))),
    Card(child: ListTile(leading: const Icon(Icons.video_library), title: const Text('Upload short video'), subtitle: const Text('Post a short video to the feed'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UploadPage(kind: 'short'))))),
    Card(child: ListTile(leading: const Icon(Icons.movie), title: const Text('Upload full film'), subtitle: const Text('Upload a longer film or movie'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UploadPage(kind: 'film'))))),
    Card(child: ListTile(leading: const Icon(Icons.photo), title: const Text('Photo post'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PhotoPostPage())))),
    Card(child: ListTile(leading: const Icon(Icons.auto_stories), title: const Text('Add your story'), subtitle: const Text('Photo/video story that expires after 24 hours'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StoryPage())))),
    Card(child: ListTile(leading: const Icon(Icons.edit), title: const Text("What's on your mind?"), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TextPostPage())))),
    Card(child: ListTile(leading: const Icon(Icons.music_note), title: const Text('Add music from phone'), subtitle: const Text('Choose audio and add it to your creator library'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MusicUploadPage())))),
    Card(child: ListTile(leading: const Icon(Icons.storefront), title: const Text('Creator Shop'), subtitle: const Text('Sell music and films with a connected payment provider'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductCreatePage())))),
    Card(child: ListTile(leading: const Icon(Icons.live_tv), title: const Text('Go Live'), subtitle: const Text('Live video, chat and gifts'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LivePage())))),
    Card(child: ListTile(leading: const Icon(Icons.event), title: const Text('Premiere'), subtitle: const Text('Schedule a music or film premiere'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PremierePage())))),
  ]);
}

class UploadPage extends StatefulWidget {
  final String kind;
  const UploadPage({super.key, required this.kind});
  @override
  State<UploadPage> createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  XFile? file;
  final picker = ImagePicker();
  final caption = TextEditingController();
  final description = TextEditingController();
  String privacy = 'public';
  bool busy = false;
  double progress = 0;

  @override
  void dispose() {
    caption.dispose();
    description.dispose();
    super.dispose();
  }

  Future<void> pick() async {
    final x = await picker.pickVideo(source: ImageSource.gallery);
    if (x != null && mounted) setState(() => file = x);
  }

  Future<void> upload() async {
    final u = FirebaseAuth.instance.currentUser;
    if (u == null || file == null) return;
    setState(() => busy = true);
    try {
      final ext = file!.name.contains('.') ? file!.name.split('.').last : 'mp4';
      final path = 'videos/${u.uid}/${DateTime.now().millisecondsSinceEpoch}.$ext';
      final ref = FirebaseStorage.instance.ref(path);
      final task = ref.putFile(File(file!.path));
      task.snapshotEvents.listen((s) {
        if (mounted && s.totalBytes > 0) {
          setState(() => progress = s.bytesTransferred / s.totalBytes);
        }
      });
      await task;
      final url = await ref.getDownloadURL();
      final ud = (await FirebaseFirestore.instance.collection('users').doc(u.uid).get()).data() ?? {};
      await FirebaseFirestore.instance.collection('videos').add({
        'uid': u.uid,
        'videoUrl': url,
        'caption': caption.text.trim(),
        'description': description.text.trim(),
        'privacy': privacy,
        'contentType': widget.kind,
        'username': ud['username'] ?? u.displayName ?? 'Creator',
        'photoUrl': ud['photoUrl'] ?? u.photoURL ?? '',
        'reactionCounts': {},
        'reactionsByUser': {},
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Video uploaded successfully.')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (context.mounted) await showError(context, e);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isFilm = widget.kind == 'film';
    return Scaffold(
      appBar: AppBar(
        title: Text(isFilm ? 'Upload Full Film' : 'Upload Short Video'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (file == null)
            OutlinedButton.icon(
              onPressed: pick,
              icon: const Icon(Icons.video_library),
              label: const Text('Choose video from phone'),
            )
          else
            Card(
              child: ListTile(
                leading: const Icon(Icons.video_file),
                title: Text(file!.name),
                trailing: IconButton(
                  onPressed: () => setState(() => file = null),
                  icon: const Icon(Icons.close),
                ),
              ),
            ),
          TextField(
            controller: caption,
            decoration: const InputDecoration(
              labelText: 'Title / caption',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: description,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Description & hashtags',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: privacy,
            decoration: const InputDecoration(
              labelText: 'Who can watch?',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'public', child: Text('🌍 Public')),
              DropdownMenuItem(value: 'private', child: Text('🔒 Private')),
              DropdownMenuItem(value: 'friends', child: Text('👥 Friends only')),
              DropdownMenuItem(value: 'followers', child: Text('👤 Followers only')),
            ],
            onChanged: (v) {
              if (v != null) setState(() => privacy = v);
            },
          ),
          if (busy)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: LinearProgressIndicator(value: progress),
            ),
          const SizedBox(height: 18),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: file == null || busy ? null : upload,
              icon: const Icon(Icons.cloud_upload),
              label: Text(busy ? 'Uploading ${(progress * 100).round()}%' : 'Upload'),
            ),
          ),
        ],
      ),
    );
  }
}

class PhotoPostPage extends StatefulWidget{const PhotoPostPage({super.key});@override State<PhotoPostPage>createState()=>_PhotoPostPageState();}
class _PhotoPostPageState extends State<PhotoPostPage>{XFile?file;int filter=0;final picker=ImagePicker();final caption=TextEditingController();bool busy=false;@override void dispose(){caption.dispose();super.dispose();}Future<void>pick()async{final x=await picker.pickImage(source:ImageSource.gallery,imageQuality:92);if(x!=null)setState(()=>file=x);}Future<void>post()async{final u=FirebaseAuth.instance.currentUser;if(u==null||file==null)return;setState(()=>busy=true);try{final f=await bakePhoto(File(file!.path),filter);final url=await uploadFile(f,'photos/${u.uid}/${DateTime.now().millisecondsSinceEpoch}.jpg');if(url==null)throw Exception('Storage upload failed. Enable Firebase Storage and deploy the included storage.rules.');final ud=(await FirebaseFirestore.instance.collection('users').doc(u.uid).get()).data()??{};await FirebaseFirestore.instance.collection('photos').add({'uid':u.uid,'url':url,'caption':caption.text.trim(),'username':ud['username']??u.displayName??'User','createdAt':FieldValue.serverTimestamp()});if(context.mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Photo posted.')));Navigator.pop(context);}}catch(e){if(context.mounted)await showError(context,e);}finally{if(mounted)setState(()=>busy=false);}}
@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Photo Post')),body:ListView(padding:const EdgeInsets.all(16),children:[if(file==null)OutlinedButton.icon(onPressed:pick,icon:const Icon(Icons.photo),label:const Text('Choose photo'))else ColorFiltered(colorFilter:photoFilters[filter],child:Image.file(File(file!.path),height:360,fit:BoxFit.cover)),const SizedBox(height:14),Wrap(spacing:8,children:[for(int i=0;i<photoFilters.length;i++)ChoiceChip(label:Text(photoFilterNames[i]),selected:filter==i,onSelected:(_)=>setState(()=>filter=i))]),const SizedBox(height:14),TextField(controller:caption,decoration:const InputDecoration(labelText:'Caption / hashtags',border:OutlineInputBorder())),const SizedBox(height:16),FilledButton(onPressed:file==null||busy?null:post,child:Text(busy?'Posting...':'Post photo'))]));}

const photoFilterNames=['Normal','B&W','Warm','Cool','Cinematic','Vivid','Vintage','Dream'];
const photoFilters=[ColorFilter.mode(Colors.transparent,BlendMode.dst),ColorFilter.matrix([.33,.33,.33,0,0,.33,.33,.33,0,0,.33,.33,.33,0,0,0,0,0,1,0]),ColorFilter.matrix([1.08,0,0,0,0,0,1.03,0,0,0,0,0,.92,0,0,0,0,0,1,0]),ColorFilter.matrix([.98,0,0,0,0,0,1.02,0,0,0,0,0,1.08,0,0,0,0,0,1,0]),ColorFilter.matrix([1.08,-.04,-.04,0,0,-.02,1.04,-.02,0,0,-.02,-.02,1.04,0,0,0,0,0,1,0]),ColorFilter.matrix([1.18,0,0,0,-10,0,1.08,0,0,-6,0,0,1.18,0,-10,0,0,0,1,0]),ColorFilter.matrix([.9,.08,.02,0,10,.02,.92,.04,0,8,0,.04,.82,0,4,0,0,0,1,0]),ColorFilter.matrix([1.05,0,.03,0,5,0,1.0,.03,0,5,.03,0,1.08,0,8,0,0,0,1,0])];
Future<File>bakePhoto(File source,int filter)async{final bytes=await source.readAsBytes();final image=img.decodeImage(bytes);if(image==null)return source;final out=img.adjustColor(image,brightness:filter==2?1.05:filter==5?1.03:filter==7?1.02:1.0,contrast:filter==4?1.12:filter==5?1.08:1.0,saturation:filter==1?0.0:filter==5?1.28:filter==6?0.72:filter==7?1.12:filter==2?1.08:1.0,hue:filter==3?-8:filter==4?-2:filter==2?10:0);final path='${Directory.systemTemp.path}/lac_${DateTime.now().millisecondsSinceEpoch}.jpg';final f=File(path);await f.writeAsBytes(img.encodeJpg(out,quality:90));return f;}

class StoryPage extends StatefulWidget{const StoryPage({super.key});@override State<StoryPage>createState()=>_StoryPageState();}
class _StoryPageState extends State<StoryPage> {
  XFile? file;
  final picker = ImagePicker();
  bool busy = false;
  Future<void> pick() async { final x = await picker.pickMedia(); if (x != null) setState(() => file = x); }
  Future<void> post() async {
    final u = FirebaseAuth.instance.currentUser; if (u == null || file == null) return;
    setState(() => busy = true);
    try {
      final video = file!.mimeType?.startsWith('video/') ?? false;
      final ext = video ? 'mp4' : 'jpg';
      final url = await uploadFile(File(file!.path), 'stories/${u.uid}/${DateTime.now().millisecondsSinceEpoch}.$ext');
      if (url == null) throw Exception('Story upload failed.');
      await FirebaseFirestore.instance.collection('stories').add({'uid': u.uid, 'url': url, 'type': video ? 'video' : 'image', 'createdAt': FieldValue.serverTimestamp(), 'expiresAt': Timestamp.fromDate(DateTime.now().add(const Duration(hours: 24)))});
      if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Story added for 24 hours.'))); Navigator.pop(context); }
    } catch (e) { if (context.mounted) await showError(context, e); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Add your story')), body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [if (file != null) Text(file!.name), FilledButton.icon(onPressed: busy ? null : pick, icon: const Icon(Icons.add_photo_alternate), label: const Text('Choose photo/video')), FilledButton(onPressed: file == null || busy ? null : post, child: Text(busy ? 'Uploading...' : 'Add story'))])));
}

class TextPostPage extends StatefulWidget{const TextPostPage({super.key});@override State<TextPostPage>createState()=>_TextPostPageState();}
class _TextPostPageState extends State<TextPostPage> {
  final text = TextEditingController(); String privacy = 'public'; bool busy = false;
  @override void dispose() { text.dispose(); super.dispose(); }
  Future<void> post() async {
    final u = FirebaseAuth.instance.currentUser; if (u == null || text.text.trim().isEmpty) return; setState(() => busy = true);
    try {
      await FirebaseFirestore.instance.collection('posts').add({'uid': u.uid, 'text': text.text.trim(), 'privacy': privacy, 'createdAt': FieldValue.serverTimestamp()});
      if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Post published.'))); Navigator.pop(context); }
    } catch (e) { if (context.mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("What's on your mind?")), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [TextField(controller: text, maxLines: 8, decoration: const InputDecoration(hintText: 'Write something...', border: OutlineInputBorder())), const SizedBox(height: 12), DropdownButtonFormField<String>(value: privacy, items: const [DropdownMenuItem(value: 'public', child: Text('🌍 Public')), DropdownMenuItem(value: 'private', child: Text('🔒 Private')), DropdownMenuItem(value: 'friends', child: Text('👥 Friends'))], onChanged: (v) => setState(() => privacy = v!), decoration: const InputDecoration(labelText: 'Privacy', border: OutlineInputBorder())), const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : post, child: Text(busy ? 'Posting...' : 'Post')))])));
}

class MusicUploadPage extends StatefulWidget{const MusicUploadPage({super.key});@override State<MusicUploadPage>createState()=>_MusicUploadPageState();}
class _MusicUploadPageState extends State<MusicUploadPage> {
  PlatformFile? file; final title = TextEditingController(); bool busy = false;
  @override void dispose() { title.dispose(); super.dispose(); }
  Future<void> pick() async { final result = await FilePicker.pickFiles(type: FileType.audio); if (result != null && result.files.isNotEmpty) setState(() => file = result.files.first); }
  Future<void> upload() async {
    final u = FirebaseAuth.instance.currentUser; if (u == null || file == null || file!.path == null) return; setState(() => busy = true);
    try {
      final url = await uploadFile(File(file!.path!), 'music/${u.uid}/${DateTime.now().millisecondsSinceEpoch}_${file!.name}'); if (url == null) throw Exception('Music upload failed.');
      await FirebaseFirestore.instance.collection('songs').add({'uid': u.uid, 'title': title.text.trim().isEmpty ? file!.name : title.text.trim(), 'url': url, 'createdAt': FieldValue.serverTimestamp()});
      if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Music added to your library.'))); Navigator.pop(context); }
    } catch (e) { if (context.mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Add Music')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [OutlinedButton.icon(onPressed: busy ? null : pick, icon: const Icon(Icons.audio_file), label: Text(file?.name ?? 'Choose audio from phone')), const SizedBox(height: 12), TextField(controller: title, decoration: const InputDecoration(labelText: 'Song title', border: OutlineInputBorder())), const SizedBox(height: 16), FilledButton(onPressed: file == null || busy ? null : upload, child: Text(busy ? 'Uploading...' : 'Add to music library'))])));
}

class CameraStudioPage extends StatefulWidget{const CameraStudioPage({super.key});@override State<CameraStudioPage>createState()=>_CameraStudioPageState();}
class _CameraStudioPageState extends State<CameraStudioPage>{final picker=ImagePicker();XFile?media;bool video=false;int filter=0;Future<void>takePhoto()async{final x=await picker.pickImage(source:ImageSource.camera,imageQuality:92);if(x!=null)setState(() {media=x;video=false;});}Future<void>record()async{final x=await picker.pickVideo(source:ImageSource.camera,maxDuration:const Duration(minutes:15));if(x!=null)setState(() {media=x;video=true;});}Future<void>choose()async{final x=await picker.pickMedia();if(x!=null)setState(() {media=x;video=x.mimeType?.startsWith('video/')??false;});}Future<void>post()async{if(media==null)return;final u=FirebaseAuth.instance.currentUser;if(u==null)return;try{final ext=video?'mp4':'jpg';final url=await uploadFile(File(media!.path),'${video?'videos':'photos'}/${u.uid}/${DateTime.now().millisecondsSinceEpoch}.$ext');if(url==null)throw Exception('Upload failed. Enable Firebase Storage and deploy storage.rules.');await FirebaseFirestore.instance.collection(video?'videos':'photos').add({'uid':u.uid,'videoUrl':video?url:null,'url':video?null:url,'caption':'','privacy':'public','reactionCounts':{},'reactionsByUser':{},'createdAt':FieldValue.serverTimestamp()});if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Posted successfully.')));}catch(e){if(context.mounted)await showError(context,e);}}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Camera & Effects')),body:ListView(padding:const EdgeInsets.all(16),children:[Container(height:340,decoration:BoxDecoration(color:Colors.black,borderRadius:BorderRadius.circular(20)),child:media==null?const Center(child:Icon(Icons.camera_alt,color:Colors.white,size:80)):video?const Center(child:Icon(Icons.videocam,color:Colors.white,size:80)):ColorFiltered(colorFilter:photoFilters[filter],child:Image.file(File(media!.path),fit:BoxFit.cover)),),const SizedBox(height:14),Wrap(spacing:8,runSpacing:8,children:[FilledButton.icon(onPressed:takePhoto,icon:const Icon(Icons.camera_alt),label:const Text('Take photo')),FilledButton.icon(onPressed:record,icon:const Icon(Icons.videocam),label:const Text('Record video')),OutlinedButton.icon(onPressed:choose,icon:const Icon(Icons.photo_library),label:const Text('Gallery'))]),const SizedBox(height:14),const Text('Filters',style:TextStyle(fontWeight:FontWeight.bold,fontSize:20)),Wrap(spacing:8,children:[for(int i=0;i<photoFilterNames.length;i++)ChoiceChip(label:Text(photoFilterNames[i]),selected:filter==i,onSelected:(_)=>setState(()=>filter=i))]),const SizedBox(height:14),Card(child:ListTile(leading:const Icon(Icons.auto_awesome),title:const Text('AI Effects'),subtitle:const Text('Secure AI backend hook prepared for cartoon, portrait and cinematic transformations.'))),FilledButton.icon(onPressed:media==null?null:post,icon:const Icon(Icons.publish),label:const Text('Post'))]));}

class ChatTab extends StatelessWidget{const ChatTab({super.key});@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Chat',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),const SizedBox(height:12),for(final item in [['Community Chat',Icons.public,()=>const CommunityChatPage()],['Private Chat',Icons.person,()=>const PrivateChatPage()],['Group Chat',Icons.groups,()=>const GroupChatPage()]])Card(child:ListTile(leading:Icon(item[1]as IconData),title:Text(item[0]as String),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>(item[2]as Widget Function())()))))]);}

class MessageBubble extends StatelessWidget{final Map<String,dynamic>d;const MessageBubble({super.key,required this.d});@override Widget build(BuildContext context){final me=d['senderId']==FirebaseAuth.instance.currentUser?.uid;final ts=d['createdAt'];String time='';if(ts is Timestamp){final dt=ts.toDate();time='${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';}return Align(alignment:me?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.symmetric(vertical:4,horizontal:10),padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),decoration:BoxDecoration(color:me?Theme.of(context).colorScheme.primaryContainer:Theme.of(context).colorScheme.surfaceContainerHighest,borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:me?CrossAxisAlignment.end:CrossAxisAlignment.start,children:[Text(d['text']??''),if(time.isNotEmpty)Text(time,style:Theme.of(context).textTheme.labelSmall)])));}}

class CommunityChatPage extends StatefulWidget{const CommunityChatPage({super.key});@override State<CommunityChatPage>createState()=>_CommunityChatPageState();}
class _CommunityChatPageState extends State<CommunityChatPage>{final message=TextEditingController();bool sending=false;@override void dispose(){message.dispose();super.dispose();}Future<void>send()async{final text=message.text.trim();final u=FirebaseAuth.instance.currentUser;if(text.isEmpty||u==null||sending)return;setState(()=>sending=true);try{await FirebaseFirestore.instance.collection('chat_messages').add({'text':text,'senderId':u.uid,'username':u.displayName??u.email??'User','createdAt':FieldValue.serverTimestamp()});message.clear();}finally{if(mounted)setState(()=>sending=false);}}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Community Chat')),body:Column(children:[Expanded(child:StreamBuilder<QuerySnapshot>(stream:FirebaseFirestore.instance.collection('chat_messages').orderBy('createdAt').limitToLast(100).snapshots(),builder:(c,s)=>ListView(children:(s.data?.docs??[]).map((x)=>MessageBubble(d:x.data()as Map<String,dynamic>)).toList()))),SafeArea(child:Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:message,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Write a message...',border:OutlineInputBorder()))),IconButton(onPressed:sending?null:send,icon:const Icon(Icons.send))])))]));}

class PrivateChatPage extends StatefulWidget{final String initialUsername;const PrivateChatPage({super.key,this.initialUsername=''});@override State<PrivateChatPage>createState()=>_PrivateChatPageState();}
class _PrivateChatPageState extends State<PrivateChatPage>{final username=TextEditingController(),message=TextEditingController();String?friendUid,chatId;bool sending=false;@override void initState(){super.initState();username.text=widget.initialUsername;}@override void dispose(){username.dispose();message.dispose();super.dispose();}Future<void>find()async{final q=username.text.trim().toLowerCase().replaceAll('@','');if(q.isEmpty)return;final s=await FirebaseFirestore.instance.collection('users').where('usernameLower',isEqualTo:q).limit(1).get();if(s.docs.isEmpty){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('User not found.')));return;}final me=FirebaseAuth.instance.currentUser!.uid;friendUid=s.docs.first.id;final ids=[me,friendUid!]..sort();setState(()=>chatId=ids.join('_'));}Future<void>send()async{if(chatId==null)return;final t=message.text.trim();final u=FirebaseAuth.instance.currentUser;if(t.isEmpty||u==null||sending)return;setState(()=>sending=true);try{await FirebaseFirestore.instance.collection('private_chats').doc(chatId).collection('messages').add({'text':t,'senderId':u.uid,'createdAt':FieldValue.serverTimestamp()});message.clear();}finally{if(mounted)setState(()=>sending=false);}}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Private Chat'),actions:[IconButton(onPressed:chatId==null?null:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CallPage(video:false))),icon:const Icon(Icons.call)),IconButton(onPressed:chatId==null?null:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CallPage(video:true))),icon:const Icon(Icons.videocam))]),body:Column(children:[if(chatId==null)Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:username,decoration:const InputDecoration(prefixText:'@',labelText:'Friend username',border:OutlineInputBorder()))),IconButton(onPressed:find,icon:const Icon(Icons.search))])),if(chatId!=null)Expanded(child:StreamBuilder<QuerySnapshot>(stream:FirebaseFirestore.instance.collection('private_chats').doc(chatId).collection('messages').orderBy('createdAt').snapshots(),builder:(c,s)=>ListView(children:(s.data?.docs??[]).map((x)=>MessageBubble(d:x.data()as Map<String,dynamic>)).toList()))),if(chatId!=null)SafeArea(child:Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:message,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Message...',border:OutlineInputBorder()))),IconButton(onPressed:sending?null:send,icon:const Icon(Icons.send))])))]));}

class GroupChatPage extends StatefulWidget{const GroupChatPage({super.key});@override State<GroupChatPage>createState()=>_GroupChatPageState();}
class _GroupChatPageState extends State<GroupChatPage>{final name=TextEditingController(text:'My Group');final member=TextEditingController();final message=TextEditingController();final List<String>members=[];bool sending=false;@override void dispose(){name.dispose();member.dispose();message.dispose();super.dispose();}Future<void>addMember()async{final q=member.text.trim().toLowerCase().replaceAll('@','');if(q.isEmpty)return;final s=await FirebaseFirestore.instance.collection('users').where('usernameLower',isEqualTo:q).limit(1).get();if(s.docs.isNotEmpty){setState(()=>members.add(s.docs.first.id));member.clear();}}Future<void>send()async{final t=message.text.trim();final u=FirebaseAuth.instance.currentUser;if(t.isEmpty||u==null||sending)return;setState(()=>sending=true);try{await FirebaseFirestore.instance.collection('groups').doc('main').collection('messages').add({'text':t,'senderId':u.uid,'createdAt':FieldValue.serverTimestamp()});message.clear();}finally{if(mounted)setState(()=>sending=false);}}@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Group Chat'),actions:[IconButton(onPressed:()=>showModalBottomSheet(context:context,builder:(_)=>Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:member,decoration:const InputDecoration(labelText:'Friend username')),FilledButton(onPressed:addMember,child:const Text('Add member')),Text('${members.length} members added')]))),icon:const Icon(Icons.person_add))]),body:Column(children:[Padding(padding:const EdgeInsets.all(10),child:TextField(controller:name,decoration:const InputDecoration(labelText:'Group name',border:OutlineInputBorder()))),Expanded(child:StreamBuilder<QuerySnapshot>(stream:FirebaseFirestore.instance.collection('groups').doc('main').collection('messages').orderBy('createdAt').snapshots(),builder:(c,s)=>ListView(children:(s.data?.docs??[]).map((x)=>MessageBubble(d:x.data()as Map<String,dynamic>)).toList()))),SafeArea(child:Padding(padding:const EdgeInsets.all(8),child:Row(children:[Expanded(child:TextField(controller:message,decoration:const InputDecoration(hintText:'Message group...',border:OutlineInputBorder()))),IconButton(onPressed:sending?null:send,icon:const Icon(Icons.send))])))]));}

class AlertsPage extends StatelessWidget {
  const AlertsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(body: Center(child: Text('Please log in.')));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .collection('notifications')
            .orderBy('createdAt', descending: true)
            .limit(100)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Notifications error: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No notifications yet.'));
          }
          return ListView(
            children: snapshot.data!.docs.map((d) {
              final data = d.data() as Map<String, dynamic>;
              return ListTile(
                leading: const Icon(Icons.notifications),
                title: Text(data['title']?.toString() ?? 'Notification'),
                subtitle: Text(data['body']?.toString() ?? ''),
                trailing: Text(_time(data['createdAt'])),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}

String _time(dynamic v){if(v is! Timestamp)return '';final d=v.toDate();return '${d.day}/${d.month} ${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';}

class ProfileTab extends StatefulWidget{const ProfileTab({super.key});@override State<ProfileTab>createState()=>_ProfileTabState();}
class _ProfileTabState extends State<ProfileTab>{final name=TextEditingController(),username=TextEditingController(),bio=TextEditingController(),youtube=TextEditingController(),facebook=TextEditingController(),instagram=TextEditingController(),tiktok=TextEditingController();final picker=ImagePicker();String?photoUrl,coverUrl;bool loading=true,saving=false;User?get user=>FirebaseAuth.instance.currentUser;@override void initState(){super.initState();load();}@override void dispose(){for(final c in [name,username,bio,youtube,facebook,instagram,tiktok])c.dispose();super.dispose();}
Future<void>load()async{final u=user;if(u==null)return;name.text=u.displayName??'';photoUrl=u.photoURL;try{final d=(await FirebaseFirestore.instance.collection('users').doc(u.uid).get()).data()??{};name.text=d['displayName']??name.text;username.text=d['username']??'';bio.text=d['bio']??'';photoUrl=d['photoUrl']??photoUrl;coverUrl=d['coverUrl'];youtube.text=d['youtube']??'';facebook.text=d['facebook']??'';instagram.text=d['instagram']??'';tiktok.text=d['tiktok']??'';}catch(_){ }if(mounted)setState(()=>loading=false);}
Future<void>pickImage({required bool cover})async{final u=user;if(u==null)return;final x=await picker.pickImage(source:ImageSource.gallery,imageQuality:88,maxWidth:1600);if(x==null)return;setState(()=>saving=true);try{final url=await uploadFile(File(x.path),'${cover?'cover_photos':'profile_photos'}/${u.uid}/${DateTime.now().millisecondsSinceEpoch}.jpg');if(url==null)throw Exception('Storage upload failed. Make sure Firebase Storage is enabled and storage.rules is deployed.');await FirebaseFirestore.instance.collection('users').doc(u.uid).set({cover?'coverUrl':'photoUrl':url},SetOptions(merge:true));if(!cover)await u.updatePhotoURL(url);if(mounted)setState(() {if(cover)coverUrl=url;else photoUrl=url;saving=false;});}catch(e){if(mounted){setState(()=>saving=false);await showError(context,e);}}}
Future<void>save()async{final u=user;if(u==null)return;if(name.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter your name.')));return;}setState(()=>saving=true);try{final uname=username.text.trim().replaceAll('@','').toLowerCase();await u.updateDisplayName(name.text.trim()).timeout(const Duration(seconds:15));await FirebaseFirestore.instance.collection('users').doc(u.uid).set({'displayName':name.text.trim(),'username':uname,'usernameLower':uname,'bio':bio.text.trim(),'photoUrl':photoUrl??'','coverUrl':coverUrl??'','youtube':youtube.text.trim(),'facebook':facebook.text.trim(),'instagram':instagram.text.trim(),'tiktok':tiktok.text.trim(),'email':u.email,'phoneNumber':u.phoneNumber,'updatedAt':FieldValue.serverTimestamp()},SetOptions(merge:true)).timeout(const Duration(seconds:15));if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Profile saved successfully.')));}catch(e){if(context.mounted)await showError(context,e);}finally{if(mounted)setState(()=>saving=false);}}
Future<void>verifyEmail()async{final u=user;if(u==null)return;await u.sendEmailVerification();if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Verification email sent.')));}
Future<void>requestBadge()async{final u=user;if(u==null)return;await FirebaseFirestore.instance.collection('verification_requests').doc(u.uid).set({'uid':u.uid,'status':'pending','createdAt':FieldValue.serverTimestamp()},SetOptions(merge:true));if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Verification request submitted.')));}
@override Widget build(BuildContext context){if(loading)return const Center(child:CircularProgressIndicator());return ListView(children:[SizedBox(height:180,child:Stack(fit:StackFit.expand,children:[coverUrl!=null&&coverUrl!.isNotEmpty?Image.network(coverUrl!,fit:BoxFit.cover):Container(color:Theme.of(context).colorScheme.primaryContainer),Positioned(right:12,bottom:12,child:FloatingActionButton.small(onPressed:saving?null:()=>pickImage(cover:true),child:const Icon(Icons.camera_alt))),Positioned(left:16,bottom:-42,child:CircleAvatar(radius:48,backgroundColor:Theme.of(context).colorScheme.surface,child:CircleAvatar(radius:43,backgroundImage:photoUrl!=null&&photoUrl!.isNotEmpty?NetworkImage(photoUrl!):null,child:photoUrl==null||photoUrl!.isEmpty?const Icon(Icons.person,size:44):null))) ])),const SizedBox(height:56),Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[CircleAvatar(radius:24,backgroundImage:photoUrl!=null&&photoUrl!.isNotEmpty?NetworkImage(photoUrl!):null,child:photoUrl==null||photoUrl!.isEmpty?const Icon(Icons.person):null),const SizedBox(width:10),Expanded(child:Text(name.text.isEmpty?'Your profile':name.text,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold))),IconButton(onPressed:saving?null:()=>pickImage(cover:false),icon:const Icon(Icons.edit))]),const SizedBox(height:16),TextField(controller:name,decoration:const InputDecoration(labelText:'Display name',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:username,decoration:const InputDecoration(labelText:'Username',prefixText:'@',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:bio,maxLines:3,decoration:const InputDecoration(labelText:'Bio',border:OutlineInputBorder())),const SizedBox(height:16),const Text('Social links',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),for(final x in [[youtube,'YouTube'],[facebook,'Facebook'],[instagram,'Instagram'],[tiktok,'TikTok']])Padding(padding:const EdgeInsets.only(top:10),child:TextField(controller:x[0]as TextEditingController,decoration:InputDecoration(labelText:x[1]as String,prefixIcon:const Icon(Icons.link),border:const OutlineInputBorder()))),const SizedBox(height:16),SizedBox(width:double.infinity,height:50,child:FilledButton(onPressed:saving?null:save,child:Text(saving?'Saving...':'Save profile'))),const SizedBox(height:10),Wrap(spacing:8,children:[OutlinedButton.icon(onPressed:verifyEmail,icon:const Icon(Icons.verified_user),label:const Text('Verify email')),OutlinedButton.icon(onPressed:requestBadge,icon:const Icon(Icons.verified),label:const Text('Request verified badge'))]),const SizedBox(height:10),OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SettingsPage())),icon:const Icon(Icons.settings),label:const Text('Account & Settings'))]))]);}
}

class PublicProfilePage extends StatefulWidget{final String uid;const PublicProfilePage({super.key,required this.uid});@override State<PublicProfilePage>createState()=>_PublicProfilePageState();}
class _PublicProfilePageState extends State<PublicProfilePage>{bool following=false,subscribed=false,friend=false,loading=true;Map<String,dynamic> d={};String get me=>FirebaseAuth.instance.currentUser!.uid;@override void initState(){super.initState();load();}Future<void>load()async{final snap=await FirebaseFirestore.instance.collection('users').doc(widget.uid).get();d=(snap.data()??{});final f=await FirebaseFirestore.instance.collection('users').doc(widget.uid).collection('followers').doc(me).get();final sub=await FirebaseFirestore.instance.collection('users').doc(widget.uid).collection('subscribers').doc(me).get();final fr=await FirebaseFirestore.instance.collection('users').doc(widget.uid).collection('friends').doc(me).get();if(mounted)setState(() {following=f.exists;subscribed=sub.exists;friend=fr.exists;loading=false;});}
Future<void>toggle(String type)async{final ref=FirebaseFirestore.instance.collection('users').doc(widget.uid).collection(type).doc(me);final exists=await ref.get();if(exists.exists){await ref.delete();}else{await ref.set({'uid':me,'createdAt':FieldValue.serverTimestamp()});}await load();}
Future<void>openUrl(String raw)async{var s=raw.trim();if(!s.startsWith('http'))s='https://$s';await launchUrl(Uri.parse(s),mode:LaunchMode.externalApplication);}
@override Widget build(BuildContext context){if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));return Scaffold(appBar:AppBar(title:const Text('Profile')),body:ListView(children:[SizedBox(height:190,child:d['coverUrl']!=null&&d['coverUrl'].toString().isNotEmpty?Image.network(d['coverUrl'],fit:BoxFit.cover):Container(color:Theme.of(context).colorScheme.primaryContainer,child:const Center(child:AppLogo(size:90)))),Padding(padding:const EdgeInsets.all(16),child:Column(children:[CircleAvatar(radius:45,backgroundImage:(d['photoUrl']??'').toString().isNotEmpty?NetworkImage(d['photoUrl']):null,child:(d['photoUrl']??'').toString().isEmpty?const Icon(Icons.person,size:45):null),const SizedBox(height:8),Row(mainAxisAlignment:MainAxisAlignment.center,children:[Text(d['displayName']??'User',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),if(d['verified']==true)const Padding(padding:EdgeInsets.only(left:6),child:Icon(Icons.verified,color:Colors.blue))]),Text('@${d['username']??''}'),const SizedBox(height:6),Text(d['bio']??'',textAlign:TextAlign.center),const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:[FilledButton.icon(onPressed:()=>toggle('followers'),icon:Icon(following?Icons.person_remove:Icons.person_add),label:Text(following?'Unfollow':'Follow')),OutlinedButton.icon(onPressed:()=>toggle('subscribers'),icon:Icon(subscribed?Icons.notifications_off:Icons.notifications_active),label:Text(subscribed?'Unsubscribe':'Subscribe')),OutlinedButton.icon(onPressed:()=>toggle('friends'),icon:Icon(friend?Icons.person_remove:Icons.group_add),label:Text(friend?'Remove friend':'Add friend')),OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PrivateChatPage(initialUsername:d['username']?.toString()??''))),icon:const Icon(Icons.chat),label:const Text('Message'))]),const SizedBox(height:14),for(final item in [['youtube','YouTube'],['facebook','Facebook'],['instagram','Instagram'],['tiktok','TikTok']])if((d[item[0]]??'').toString().isNotEmpty)ListTile(leading:const Icon(Icons.link),title:Text(item[1]),onTap:()=>openUrl(d[item[0]].toString()))]))]));}}

class SettingsPage extends StatelessWidget{const SettingsPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Settings')),body:ListView(children:[ListTile(leading:const Icon(Icons.logout),title:const Text('Log out'),onTap:()async{await FirebaseAuth.instance.signOut();if(context.mounted)Navigator.popUntil(context,(r)=>r.isFirst);}),const ListTile(leading:Icon(Icons.security),title:Text('Privacy & Safety'),subtitle:Text('Block, report, private/public content and account controls')),const ListTile(leading:Icon(Icons.payment),title:Text('Creator Wallet'),subtitle:Text('Prepared for mobile money, card sales and live gifts')),const ListTile(leading:Icon(Icons.live_tv),title:Text('Live'),subtitle:Text('Live streaming and gifts require a realtime media backend')),const ListTile(leading:Icon(Icons.call),title:Text('Voice & Video Calls'),subtitle:Text('Call UI is prepared; realtime signaling/backend is required'))]));}

class StoryPagePlaceholder extends StatelessWidget{const StoryPagePlaceholder({super.key});@override Widget build(BuildContext context)=>const SizedBox();}

class LivePage extends StatelessWidget{const LivePage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Live')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.live_tv,size:90),const SizedBox(height:12),const Text('Go Live',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),const Text('The live screen is prepared for realtime streaming, chat, reactions and gifts. A streaming/signaling backend is required for the actual broadcast.'),const SizedBox(height:18),FilledButton.icon(onPressed:()=>showDialog(context:context,builder:(_)=>const AlertDialog(title:Text('Live setup'),content:Text('Next backend step: realtime media server + moderation + gift wallet.'))),icon:const Icon(Icons.videocam),label:const Text('Start Live'))]))));}

class PremierePage extends StatelessWidget{const PremierePage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Premiere')),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('Premiere music or film',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),const SizedBox(height:12),const Text('Schedule a release, countdown, notify followers and open premiere chat.'),const SizedBox(height:20),FilledButton(onPressed:()=>showDialog(context:context,builder:(_)=>const AlertDialog(title:Text('Premiere scheduling'),content:Text('Premiere scheduling is connected to Firestore. Payment/streaming delivery should be connected through a trusted payment and media backend.'))),child:const Text('Create premiere'))]));}

class MarketplacePage extends StatelessWidget{const MarketplacePage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Music & Film Shop')),body:StreamBuilder<QuerySnapshot>(stream:FirebaseFirestore.instance.collection('products').where('published',isEqualTo:true).limit(100).snapshots(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.docs.isEmpty)return const Center(child:Text('No products yet. Creators can publish music and films here.'));return ListView(children:s.data!.docs.map((d)=>ListTile(leading:const Icon(Icons.store),title:Text(d['title']??'Item'),subtitle:Text('${d['type']??'Content'} • ${d['price']??''}'),trailing:FilledButton(onPressed:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Purchase'),content:const Text('Connect this button to your selected mobile-money/card payment provider before taking real payments.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])),child:const Text('Buy')))).toList());}));}

class EditorPage extends StatefulWidget{final XFile media;final bool video;const EditorPage({super.key,required this.media,required this.video});@override State<EditorPage>createState()=>_EditorPageState();}
class _EditorPageState extends State<EditorPage>{int filter=0;double brightness=0,contrast=1;@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.video?'Video Editor':'Photo Editor')),body:ListView(padding:const EdgeInsets.all(16),children:[Container(height:330,color:Colors.black,child:widget.video?const Center(child:Icon(Icons.movie,color:Colors.white,size:70)):ColorFiltered(colorFilter:photoFilters[filter],child:Image.file(File(widget.media.path),fit:BoxFit.contain))),const SizedBox(height:14),const Text('Filters',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Wrap(spacing:8,children:[for(int i=0;i<photoFilterNames.length;i++)ChoiceChip(label:Text(photoFilterNames[i]),selected:filter==i,onSelected:(_)=>setState(()=>filter=i))]),if(widget.video)...[const SizedBox(height:18),const Text('Video tools'),RangeSlider(values:const RangeValues(0,1),onChanged:(_){},labels:const RangeLabels('Start','End')),const Text('Trim, crop, speed, mute, music, text and stickers are part of the editor foundation; media export needs a native processing backend/package.')],const SizedBox(height:18),FilledButton.icon(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.check),label:const Text('Done'))]));}

class FriendRequestPage extends StatelessWidget{const FriendRequestPage({super.key});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Friends')),body:const Center(child:Text('Friend requests, accept/decline and remove-friend controls are ready for the social graph backend.')));}


class ProductCreatePage extends StatefulWidget{const ProductCreatePage({super.key});@override State<ProductCreatePage>createState()=>_ProductCreatePageState();}
class _ProductCreatePageState extends State<ProductCreatePage> {
  final title = TextEditingController(), price = TextEditingController(); String type = 'song'; bool busy = false;
  @override void dispose() { title.dispose(); price.dispose(); super.dispose(); }
  Future<void> publish() async {
    final u = FirebaseAuth.instance.currentUser; if (u == null || title.text.trim().isEmpty) return; setState(() => busy = true);
    try {
      await FirebaseFirestore.instance.collection('products').add({'uid': u.uid, 'title': title.text.trim(), 'price': price.text.trim(), 'type': type, 'published': true, 'createdAt': FieldValue.serverTimestamp()});
      if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Item added to your shop.'))); Navigator.pop(context); }
    } catch (e) { if (context.mounted) await showError(context, e); } finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Creator Shop')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'Music or film title', border: OutlineInputBorder())), const SizedBox(height: 12), DropdownButtonFormField<String>(value: type, items: const [DropdownMenuItem(value: 'song', child: Text('Song')), DropdownMenuItem(value: 'album', child: Text('Album')), DropdownMenuItem(value: 'film', child: Text('Full film'))], onChanged: (v) => setState(() => type = v!), decoration: const InputDecoration(labelText: 'Content type', border: OutlineInputBorder())), const SizedBox(height: 12), TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price', hintText: 'e.g. 5000 UGX', border: OutlineInputBorder())), const SizedBox(height: 18), SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : publish, child: Text(busy ? 'Publishing...' : 'Publish for sale'))), const SizedBox(height: 10), const Text('Connect your approved mobile-money/card provider on the secure backend before taking real payments.', textAlign: TextAlign.center)])));
}

class CallPage extends StatelessWidget{final bool video;const CallPage({super.key,required this.video});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(video?'Video call':'Voice call')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(video?Icons.videocam:Icons.call,size:90),const SizedBox(height:12),Text(video?'Video call':'Voice call',style:const TextStyle(fontSize:28,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('Call interface is ready. Connect a realtime signaling/media service before enabling real calls.'),const SizedBox(height:18),FilledButton.icon(onPressed:()=>Navigator.pop(context),icon:const Icon(Icons.call_end),label:const Text('End'))]))));}
