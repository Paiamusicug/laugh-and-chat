# Laugh & Chat v2.0.1

Corrected Android build package for the Laugh & Chat Firebase-connected Flutter app.

## What was corrected
- Fixed Dart widget nesting/parentheses in the upgraded source.
- Pinned key packages to known-compatible versions instead of allowing surprise major/minor resolution changes.
- Reverted `file_picker` to 11.0.3 and restored its v11 API usage.
- Raised Android compile/target SDK to 36.
- Added Android camera/internet/gallery permissions required by the included media features.
- Kept Firebase Storage paths aligned with the included storage rules.
- Version: 2.0.1+9.

## Important Firebase setup
1. In Firebase Console, open **Storage** and click **Get started** if Storage has not been created yet.
2. Deploy `storage.rules` and `firestore.rules` from this project.
3. Keep `android/app/google-services.json` in place.
4. Email/Password and Phone authentication must be enabled.
5. Phone authentication also requires the appropriate Android app fingerprints and Firebase SMS settings.

## Build
The project is intended for Flutter 3.47.2 stable, matching the current Flutter documentation baseline.

The app contains foundations/placeholders for advanced backend features such as real AI effects, live streaming, voice/video calls, and payments. Those require secure backend/provider integrations and are not implemented by embedding secret API keys in the APK.
