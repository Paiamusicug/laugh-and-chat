package com.humblet.laughandchat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
