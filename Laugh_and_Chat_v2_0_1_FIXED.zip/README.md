# Laugh & Chat v2.0

Major upgrade foundation for the Laugh & Chat social platform.

## Included
- Branded Laugh & Chat logo in the app and launcher-ready asset.
- Email/password and phone authentication.
- Email verification and verified-badge request flow.
- Home video feed with emoji reactions, save, repost, share and download-to-gallery.
- Short-video and full-film upload with public/private/friends/followers privacy choices.
- Photo posts, stories, text posts ("What's on your mind?"), camera and filters.
- Photo filter baking and editor foundation.
- Music upload from phone.
- Search foundation for users/videos/songs/effects/films.
- Private chat by username, group chat member-add UI, message timestamps and sent/received bubbles.
- Profile cover photo, profile photo, bio and YouTube/Facebook/Instagram/TikTok links.
- Follow/subscribe profile actions.
- Real Firestore notification screen foundation.
- Logout and settings.
- Creator marketplace/premiere/live screens prepared for backend payment/media integrations.

## Important Firebase setup
1. In Firebase Console, open **Storage** and click **Get started** if Storage has not been enabled yet. The previous object-not-found upload errors can occur when Storage is not ready.
2. Deploy the included `storage.rules` and `firestore.rules` (Firebase CLI: `firebase deploy --only storage,firestore`).
3. Keep the existing `google-services.json` in `android/app/`.
4. Email/Phone Authentication providers must remain enabled.
5. For production, replace the starter Firestore rules with stricter per-user/private-content rules before public launch.

## Features that need a server/provider before they can be truly live
- AI/OpenAI media transformations: secure backend required; never ship an API key in the APK.
- Real voice/video calls: WebRTC signaling/media backend required.
- Live streaming: realtime media streaming backend required.
- Mobile-money/card checkout and creator payouts: payment provider + secure server/webhook required.
- Full video export/editing (trim, music, transitions) needs native media processing.

The app UI and Firestore/Storage foundations for these features are included so they can be connected without redesigning the app.

## v2.0.1 fixes
- Video feed accepts older public video documents even when `privacy` is missing.
- Video cards now show labeled Like, Comment, Repost, Share, Download and Save controls.
- Video loading errors are shown clearly instead of silently showing an unusable player.
- Feed sorting and pull-to-refresh were improved.
